<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class HistoryPersonal extends Model
{
    //
}
