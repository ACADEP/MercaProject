<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TrainingAssign extends Model
{
    //
}
