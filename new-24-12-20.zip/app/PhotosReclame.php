<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PhotosReclame extends Model
{
    protected $fillable = ['sale_id', 'path'];
}
