<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Confirmación de restablecimiento de contraseña</title>
</head>
<body>


<h1>Recuperación de contraseña!</h1>


<p>
    Solo necesitamos que <a href='{{ url("/password/reset") }}'>confirme su correo electrónico</a> gracias!
</p>


</body>
</html>