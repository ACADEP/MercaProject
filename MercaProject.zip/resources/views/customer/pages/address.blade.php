@extends('customer.dash')

@section('content')

<div class="row col-12 col-sm-12 col-md-12 col-lg-12">
    <div><h1 class="address ml-5">Direcciones</h1></div>
    <div class="col-12 col-sm-12 col-md-12 col-lg-12">
        
    </div>
    <div class="col-12 col-sm-12 col-md-12 col-lg-12">
        <a href="#AgregarDirección" class="btn btn-success text-center"><i class="fa fa-plus" aria-hidden="true"></i> Agregar Dirección</a>
    </div>    
</div>

@endsection