@extends('customer.dash')

@section('content')

<h1>hola women</h1>

@stop