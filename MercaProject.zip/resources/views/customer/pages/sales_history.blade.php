@extends('seller.dash')

@section('content')
<section class="content-header">
        <h1>
            Mi historial de ventas<br>
            <small>Lista ventas</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Level</a></li>
            <li class="active">Here</li>
        </ol>
    </section><br>
    <table class="text-center table">
    <thead>
            <tr>
                <th>Producto</th>
                <th>Nombre del producto</th>
                <th>Precio unt</th>
                <th>Cliente</th>
                <th>Fecha de la venta</th>
                <th>Cantidad</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>#</td>
                <td>dsd</td>
                <td>$6</td>
                <td>yO</td>
                <td>12/12/12</td>
                <td>1</td>
                
            
            </tr>
        
        </tbody>
    
    </table>
    
@stop