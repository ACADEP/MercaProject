@extends('customer.dash')

@section('content')
<section class="content-header">
        <h1>
            Mi historial de compra
        </h1>
    </section><br>
    <table class="text-center table">
    <thead>
            <tr>
                <th>Nombre del producto</th>
                <th>Precio untitario</th>
                <th>Fecha de compra</th>
                <th>Cantidad</th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
            <tr>
               
                <td>dsd</td>
                <td>$6</td>
                <td>yO</td>
                <td>12/12/12</td>
                <td>1</td>
                
            
            </tr>
        
        </tbody>
    
    </table>
    
@stop