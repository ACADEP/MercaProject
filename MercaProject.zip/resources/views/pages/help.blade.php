@extends('app')

@section('content')

<div>
    <h1>Ayudaa!!!!</h1>
</div>

@endsection
