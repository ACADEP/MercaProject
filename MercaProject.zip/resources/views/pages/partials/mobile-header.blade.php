





<div id="tf-home-m" class="text-center">
    <div class="overlay">
        <div class="content">
            <h1><strong><span class="color">Store</span></strong></h1>
            <p class="lead">Shop your favorite electronics, brands and more!</p>
            <a href="#featured-products-heading" class="btn btn-border-primary waves-effect" id="arrow-btn"><i class="material-icons">arrow_downward</i></a>
        </div>
    </div>
</div>