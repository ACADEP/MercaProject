<div class="col-md-12" id="breads">
    <h4 class="text-left animated zoomIn" id="title-product">Tiendas</h4><a href="#">Ver todas</a>
        <div class="text-center" >
            

                <div id="featured-products-sub-container">
                    <div class="row">
                        <!-- Tiendas -->
                        
                            <div class="col-sm-6 col-md-3 animated zoomIn" >
                                
                                <div class="card border-primary mb-3" style="max-width: 18rem;">
                                    <div class="card-header">HP</div>
                                    <div class="card-body text-primary" id="store-card">
                                        <h5 class="card-title">Tienda electronica</h5>
                                        <p class="card-text">Esta la tienda oficial de HP</p>
                                    </div>
                                </div>
                            </div>
                        

                         <div class="col-sm-6 col-md-3 animated zoomIn" >
                            <div class="card border-primary mb-3" style="max-width: 18rem;">
                                <div class="card-header">Dell</div>
                                <div class="card-body text-primary" id="store-card">
                                    <h5 class="card-title">Tienda electronica</h5>
                                    <p class="card-text">Esta la tienda oficial de HP</p>
                                </div>
                            </div>
                        </div>

                         <div class="col-sm-6 col-md-3 animated zoomIn" >
                            <div class="card border-primary mb-3" style="max-width: 18rem;">
                                <div class="card-header">Microsoft</div>
                                <div class="card-body text-primary" id="store-card">
                                    <h5 class="card-title">Tienda electronica</h5>
                                    <p class="card-text">Esta la tienda oficial de HP</p>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            
        </div>
</div>