@extends('app')

@section('content')

<h1>Hola</h1>


@endsection
