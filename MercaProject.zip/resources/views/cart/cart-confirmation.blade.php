@extends('app')

@section('content')

<h1>Hola Jonatan</h1>


@endsection
