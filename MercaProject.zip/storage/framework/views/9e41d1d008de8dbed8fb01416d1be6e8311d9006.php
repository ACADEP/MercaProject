<div class="col-md-12" id="breads">
    <h4 class="text-left animated zoomIn" id="title-product">Tiendas</h4>
    <a href="<?php echo e(route('all.shops')); ?>">Ver todas</a>
        <div class="text-center" >
            

                <div id="featured-products-sub-container">
                    <div class="row">
                        <!-- Tiendas -->
                        <?php $__currentLoopData = $rand_shops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shops): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                            <div class="col-sm-6 col-md-3 animated zoomIn" >
                                <a href="<?php echo e(route('shop', $shops->id)); ?>" style="text-decoration:none;">
                                <div class="card border-primary mb-3" style="max-width: 18rem; height: 200px;">
                                    <div class="card-header header-color"><?php echo e($shops->name); ?></div>
                                    <div class="card-body text-primary" id="shop-card">
                                        <img class="img-fluid" src="<?php echo e($shops->path); ?>" alt="First slide" width="100%" height="200">
                                    </div>
                                </div>
                            </div>
    
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
            
        </div>
</div>