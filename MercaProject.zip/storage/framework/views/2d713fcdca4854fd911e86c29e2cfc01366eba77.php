<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <h1 class="text-center">Categorias</h1>
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <ul>
           <li><a href="#" style="text-decoration: none;"><?php echo e($category->category); ?></a></li>
        </ul>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>