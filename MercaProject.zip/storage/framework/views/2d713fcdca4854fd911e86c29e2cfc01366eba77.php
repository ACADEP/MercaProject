<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <h1 class="text-center">Categorías</h1>
    <?php $__currentLoopData = $categoriesall; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($category->totalSubcategories() > 0): ?>
        <ul >
            <li> <a href="#" ><?php echo e($category->category); ?></a></li>
           <ul style="text-decoration: none;">
           <?php $__currentLoopData = $category->children()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <li><a href="#" ><?php echo e($sub->category); ?></a></li>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
           
           </ul>
        </ul>
        <?php else: ?>
        <ul >
           <li style="text-decoration: none;"><a href="#" ><?php echo e($category->category); ?></a></li>
        </ul>
        <?php endif; ?>
        

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>