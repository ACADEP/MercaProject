<!-- <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
        Busqueda especializada
</button> -->

<style>
    .ajuste {
      padding-left: 32px;
    }
    .alineado {
    }
    .ordenado {
    }
    .filters {
    }
</style>

    <!-- Modal -->
<div class="modal fade bd-example-modal-lg" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Búsqueda avanzada</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
          <div class="filters col-sm-12 col-md-12 col-lg-12">
              <form class="form-inline" action="<?php echo e(route('special.filter')); ?>" method="GET">
                  <?php
                      $categorias=App\Category::all();
                      $marcas=App\Brand::all();
                  ?>
                  <div class="form-row align-items-center">
                      <div class="dropdown ajuste alineado">
                          <button class="btn btn-info dropdown-toggle" type="button" id="dropdownMenu1" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                              Marcas
                              <span class="caret"></span>
                          </button>
                          <ul class="dropdown-menu check filter-color text-left" aria-labelledby="dropdownMenu1">
                              <?php $__currentLoopData = $marcas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <li><label for="<?php echo e('bra'.$marca->id); ?>"><input class="text-left" type="checkbox" name="brand[]" value="<?php echo e($marca->id); ?>, <?php echo e($marca->brand_name); ?>" id="<?php echo e('bra'.$marca->id); ?>" /><strong class="ml-1"><?php echo e($marca->brand_name); ?></strong></label></li>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </ul>
                      </div>
          
                      <div class="dropdown ajuste alineado">
                          <button class="btn btn-info dropdown-toggle" type="button" id="dropdownMenu2" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
                              Categorias   
                              <span class="caret"></span>
                          </button>
                          <ul class="dropdown-menu check filter-color" aria-labelledby="dropdownMenu2">
                              <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <li><label for="<?php echo e('cat'.$categoria->id); ?>"><input class="text-left" type="checkbox" name="categories[]" value="<?php echo e($categoria->id); ?>, <?php echo e($categoria->category); ?>" id="<?php echo e('cat'.$categoria->id); ?>" /><strong class="ml-1"><?php echo e($categoria->category); ?></strong></label></li>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </ul>
                      </div>
          
                      <div class="ajuste minimo">
                          <input type="text" name="desde" class="form-control" placeholder="$ Mínimo" style="width: 100px;">
                      </div>
          
                      <div class="ajuste maximo">
                          <input type="text" name="hasta" class="form-control ml-2" placeholder="$ Máximo" style="width: 100px;">
                      </div>     
                      <div class="ajuste alineado">
                            <input type="hidden" name="fil" value="1">
                            <button class="btn btn-info" type="submit"><i class="fa fa-search fa-lg" style="width: 20px;" aria-hidden="true"></i></button>
                      </div>                    
                  </div>
              </form>
          </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
        
      </div>
    </div>
  </div>
</div>


