<?php $__env->startSection('content'); ?>
     
            <h6>
               Resultados para:  <i><?php echo e($query); ?></i>
            </h6><br>
               
                <?php if(count($search) == 0 || $search==null): ?>
                 <div class="text-center" style="height:300px;"><h1>No hay productos</h1> </div>   
                <?php elseif(count($search) >= 1): ?>
                    <?php $__currentLoopData = $search; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $query): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4 wow slideInLeft" id="product-sub-container">
                            <div class="text-center hoverable">
                                <a href="<?php echo e(route('show.product', $query->product_name)); ?>">
                                <?php if($query->photos->count() === 0): ?>
                                        <img src="/images/no-image-found.jpg" alt="No Image Found Tag">
                                <?php else: ?>
                                    <?php if($query->featuredPhoto): ?>
                                        <img src="<?php echo e($query->featuredPhoto->thumbnail_path); ?>" alt="Photo ID: <?php echo e($query->featuredPhoto->id); ?>" width="100%" />
                                    <?php elseif(!$query->featuredPhoto): ?>
                                        <img src="<?php echo e($query->photos->first()->thumbnail_path); ?>" alt="Photo" />
                                    <?php else: ?>
                                        N/A
                                    <?php endif; ?>
                                <?php endif; ?>
                                </a>
                            </div>
                            <div class="text-center">
                                <a href="<?php echo e(route('show.product', $query->product_name)); ?>">
                                <h5 class="center-on-small-only"><?php echo e($query->product_name); ?></h5>
                                <h6 class="center-on-small-only">Marcas: <?php echo e($query->brand->brand_name); ?></h6>
                                <p style="font-size: .9em;"><?php echo nl2br(str_limit($query->description, $limit = 200, $end = '...')); ?></p>
                                </a>
                            </div>
                            <div class="text-center">
                                <?php if($query->reduced_price == 0): ?>
                                    $ <?php echo e($query->price); ?>

                                    <br>
                                <?php else: ?>
                                    <div class="text-danger list-price"><s>$ <?php echo e($query->price); ?></s></div>
                                    $ <?php echo e($query->reduced_price); ?>

                                <?php endif; ?>
                                <br><br><br>
                                    <input type="hidden" id="product_id<?php echo e($query->id); ?>" value="<?php echo e($query->id); ?>"/>
                                    <input type="hidden" id="qty" value="1"/>
                                    <input type="hidden" id="url" value="<?php echo e(route('addCart')); ?>">
                                    <button class="btn btn-default btn-addcart" value="<?php echo e($query->id); ?>"><i class="fa fa-cart" aria-hidden="true"></i>Agregar al carrito</button>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
           
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>