<?php $__env->startSection('content'); ?>
     
            <h4><br>
               Resultados para:  <i><?php echo e($query); ?></i>
            </h4><br>
            <div class="row col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
                <?php if(count($search) == 0 || $search==null): ?>
                 <div class="text-center" style="height:300px;"><h1>No hay productos</h1> </div>   
                <?php elseif(count($search) >= 1): ?>
                    <?php $__currentLoopData = $search; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $query): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-12 col-sm-6 col-md-4 col-lg-3 col-xl-3 wow slideInLeft mb-2 ml-3 pt-3 pb-2" id="product-sub-container" style="max-width: 23%;">
                            <div class="row">
                                <div class="row col-3 col-sm-3 col-md-3 col-lg-3 pl-1" style="float: left; height: 80%;">
                                    <span class="d-inline-block" tabindex="0" data-toggle="tooltip" title="Agregar al carrito" style="margin-left: 460%;">
                                        <button class="btn btn-primary btn-rounded waves-effect waves-light btn-addcart" value="<?php echo e($query->id); ?>">
                                            <i class="material-icons" style="line-height: 2">add_shopping_cart</i><!--<i class="fa fa-plus" aria-hidden="true"></i>Agregar al carrito-->
                                        </button>
                                    </span>
                                </div>
                                <div class="row col-9 col-sm-9 col-md-9 col-lg-9 d-block pt-1 text-center hoverable">
                                    <a href="<?php echo e(route('show.product', $query->product_name)); ?>">
                                    <?php if($query->photos->count() === 0): ?>
                                            <img src="/images/no-image-found.jpg" class="img-fluid" alt="No Image Found Tag">
                                    <?php else: ?>
                                        <?php if($query->featuredPhoto): ?>
                                            <img src="<?php echo e($query->featuredPhoto->thumbnail_path); ?>" class="img-fluid" alt="Photo ID: <?php echo e($query->featuredPhoto->id); ?>" width="100%" />
                                        <?php elseif(!$query->featuredPhoto): ?>
                                            <img src="<?php echo e($query->photos->first()->thumbnail_path); ?>" class="img-fluid" alt="Photo" />
                                        <?php else: ?>
                                            N/A
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    </a>
                                </div>
                            </div>
                            <div class="text-center">
                                <?php
                                    $acorName = substr($query->product_name, 0, 25);
                                    $acorDesc = substr($query->description, 0, 25);
                                ?>
                                <a href="<?php echo e(route('show.product', $query->product_name)); ?>">
                                <h5 class="center-on-small-only"><?php echo e($acorName); ?></h5>
                                <h6 class="center-on-small-only">Marcas: <?php echo e($query->brand->brand_name); ?></h6>
                                <p style="font-size: .9em;"><?php echo nl2br(str_limit($query->description, $limit = 200, $end = '...')); ?></p>
                                </a>
                            </div>
                            <div class="text-center">
                                <?php if($query->reduced_price == 0): ?>
                                    <i class="fa fa-tag" style="color: green" aria-hidden="true"></i> $ <?php echo e($query->price); ?>

                                    <br>
                                <?php else: ?>
                                    <div class="text-danger list-price"><s style="color: red">$ <?php echo e(number_format($query->price, 2)); ?><i class="fa fa-tag" aria-hidden="true"></i></s></div>
                                    <div class="blue-text light-300 medium-500" id="Product_Reduced-Price">$ <?php echo e(number_format(($query->price-$query->reduced_price), 2)); ?></div>
                                <?php endif; ?>
                                    <input type="hidden" id="product_id<?php echo e($query->id); ?>" value="<?php echo e($query->id); ?>"/>
                                    <input type="hidden" id="qty" value="1"/>
                                    <input type="hidden" id="url" value="/cart/add">
                                    
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>