<?php $__env->startSection('content'); ?>

<nav aria-label="breadcrumb" style="padding-top: 5px;">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Inicio</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(url('/customer/profile')); ?>">Perfil</a></li>
        <li class="breadcrumb-item active" aria-current="page">Datos de Cuenta</li>
    </ol>
</nav>        
    
<section class="content-header">
        <h1>
            Datos de Cuenta 
        </h1> 
</section><br>     

<div class="text-center" style="margin-right: 14%; padding-bottom: 20px;">
    <button class="btn btn-success"  data-toggle="modal" data-target="#add_address"><i class="fa fa-plus-square" aria-hidden="true"></i> Actualizar</button>
</div>
<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
    
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('mostrar-modal'); ?>
    <?php if($errors->any()): ?>
        <script>
            $(function() {
                $('#add_address').modal('show');
            });
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('customer.dash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>