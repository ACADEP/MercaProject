<?php $__env->startSection('content'); ?>

<nav aria-label="breadcrumb" style="padding-top: 5px;">
    <ol class="breadcrumb breadcrumb-right-arrow">
        <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Inicio</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(url('/seller/admin')); ?>">Perfil</a></li>
        <li class="breadcrumb-item active" aria-current="page">Historial de Reclamos</li>
    </ol>
</nav>          

<section class="content-header">
        <h1>
            Historial del reclamos
        </h1>   
</section><br>
<?php if($sales->count()>0): ?>
<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
<?php $i=1;?>
<?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="panel panel-default">
    <div class="panel-heading" role="tab" id="heading<?php echo e($i); ?>">
      <h4 class="panel-title">
        <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse<?php echo e($i); ?>" aria-expanded="true" aria-controls="collapse<?php echo e($i); ?>">
            Por: <?php echo e($sale->client->username); ?> -  Fecha: <?php echo e(date('d-m-Y', strtotime($sale->date_reclame))); ?> Hora: <?php echo e(date('H:i:s', strtotime($sale->date_reclame))); ?>

        </a>
      </h4>
    </div>
    <div id="collapse<?php echo e($i); ?>" class="<?php echo e($i==1 ? 'panel-collapse collapse in' : 'panel-collapse collapse'); ?>" role="tabpanel" aria-labelledby="heading<?php echo e($i); ?>">
      <div class="panel-body">
        <div class="text-center">
            <h4><strong> Compra</strong></h4>
        </div>
            <table class="table text-center">
            <thead>
                    <tr>
                        <th></th>
                        <th>Producto</th>
                        <th>Cantidad</th>
                        <th>Precio untitario</th>
                        
                    </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $sale->customerHistories()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><img src="<?php echo e($history->product->photos()->first()->path); ?>" style="height:30px"></td>
                        <td><?php echo e($history->product_name); ?></td>
                        <td><?php echo e($history->amount); ?></td>
                        <td>$<?php echo e(number_format($history->product_price, 2)); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
            </tbody>
            </table>
           <div class="text-right"><h4><strong>Total: <span class="label label-success">$<?php echo e(number_format($sale->total, 2)); ?></span></strong></h4></div>
           <div class="col-md-8 well well-lg">
                <div class="form-inline col-md-12 text-right">
                    <label for="estado">Asignar estatus: </label>
                    <select name="state_reclame" id="estado<?php echo e($sale->id); ?>">
                        <option selected value="Aceptado">Aceptado</option>
                        <option value="Rechazado">Rechazado</option>
                    </select>
                </div> 
                <h4><strong>Descripción:</strong></h4>
                <?php echo $sale->reclame_text; ?>

                <div class="form-inline col-md-12 text-center">
                    <button class="btn btn-primary btn-sm btn-response" value="<?php echo e($sale->id); ?>" data-toggle="modal" data-target="#respond-reclame">Responder</button>
                </div> 
            
            </div>
            <div class="col-md-4 well well-lg">
                <h4><strong>Imágenes anexas:</strong></h4>
                <?php if($sale->photosReclame()->count()>0): ?>
                <?php $__currentLoopData = $sale->photosReclame()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6"><img class="img-responsive" src="<?php echo e($photo->path); ?>"></div>
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                <h4>No hay imágenes</h4>
                <?php endif; ?>
            </div>
           
          
<!-- Fin panel body--></div>

 <!--Fin collapse-->   </div>
 
    <?php $i++;?>
    
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    
    <div class="text-center">
        <!-- links -->
    </div>
<?php else: ?>
    <h4>No hay reclamos pendientes</h4>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('select-sale'); ?>
    <script>
         $(document).ready(function() {
            $(".btn-response").click(function(){
                $("#sale").val($(this).val());
                $("#reclame_state").val($("#estado"+$(this).val()).val());
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('modal-respond-reclame'); ?>
<div class="modal fade" id="respond-reclame" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title text-center" id="exampleModalLongTitle">Responder reclamo</h1>
      </div>
      <div class="modal-body">
        <form action="<?php echo e(route('respond-reclame')); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <p>Escriba su respuesta aquí:</p>
            <div id="summernote"></div>
            Caracteres restantes: <span id="maxContentPost"></span>
            <textarea name="reclame_text" style="display:none;" id="reclame_text2"></textarea>
            <div class="text-center">
                <input type="hidden" id="sale" name="sale">
                <input type="hidden" id="reclame_state" name="reclame_state">
                <button type="submit" class="btn btn-primary send">Enviar</button>
                <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
            </div>
        </form>
        
        
        <script>
            $(document).ready(function() {
                $('#summernote').summernote({
                    height: 200,
                    callbacks: {
                        
                        onKeydown: function (e) { 
                        var t = e.currentTarget.innerText; 
                        if (t.trim().length >= 288) {
                            //delete keys, arrow keys, copy, cut
                            if (e.keyCode != 8 && !(e.keyCode >=37 && e.keyCode <=40) && e.keyCode != 46 && !(e.keyCode == 88 && e.ctrlKey) && !(e.keyCode == 67 && e.ctrlKey))
                            e.preventDefault(); 
                        } 
                        },
                        onKeyup: function (e) {
                            var t = e.currentTarget.innerText;
                            $('#maxContentPost').text(288 - t.trim().length);
                        },
                        onPaste: function (e) {
                            var t = e.currentTarget.innerText;
                            var bufferText = ((e.originalEvent || e).clipboardData || window.clipboardData).getData('Text');
                            e.preventDefault();
                            var maxPaste = bufferText.length;
                            if(t.length + bufferText.length > 288){
                                maxPaste = 288 - t.length;
                            }
                            if(maxPaste > 0){
                                document.execCommand('insertText', false, bufferText.substring(0, maxPaste));
                            }
                            $('#maxContentPost').text(288 - t.length);
                        }
                        
                    },
                    toolbar: [
                        // [groupName, [list of button]]
                        ['style', ['bold', 'italic', 'underline', 'clear']],
                        ['font', ['strikethrough', 'superscript', 'subscript']],
                        ['fontsize', ['fontsize']],
                        ['color', ['color']],
                        ['para', ['ul', 'ol', 'paragraph']],
                        ['height', ['height']]
                    ]
                });

                $(".send").click(function(){
                    var markupStr = $('#summernote').summernote('code');
                    $('#reclame_text2').val(markupStr);
                });
            });
        </script>
        
        
      </div>
      
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('seller.dash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>