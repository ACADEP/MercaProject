<?php $__env->startSection('content'); ?>

    <div id="wrapper">

            <!-- Sidebar -->
            <div id="sidebar-wrapper">
                <ul class="sidebar-nav">

                    <li>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                            Marcas <span class="caret"></span>
                            <ul class="dropdown-menu">
                                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li id="dropdown-category">
                                        <a href="<?php echo e(url('brand', $brand->id)); ?>">
                                            <?php echo e($brand->brand_name); ?>

                                        </a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </a>
                    </li>
                    </li>

                    <br><br>

                    <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                <?php echo e($cat->category); ?> <span class="caret"></span>
                                <ul class="dropdown-menu">
                                    <?php $__currentLoopData = $cat->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $children): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li id="dropdown-category">
                                            <a href="<?php echo e(url('category', $children->id)); ?>">
                                                <?php echo e($children->category); ?>

                                            </a>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </a>
                        </li>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <br><br>

                    <li>
                        <a href="<?php echo e(url('admin/dashboard')); ?>">
                            ADMIN
                        </a>
                    </li>

                </ul>
            </div>
            <a href="#menu-toggle" class="btn btn-default" id="menu-toggle"><i class="fa fa-bars fa-5x"></i></a>


        <div class="container-fluid">

            <h3 class="text-center">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($category->category); ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </h3>

            <div class="dropdown">
                <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Sort By
                    <span class="caret"></span></button>
                <ul class="dropdown-menu">
                    <li><a href="<?php echo e(route('category.newest', $category->id)); ?>">Newest</a></li>
                    <li><a href="<?php echo e(route('category.lowest', $category->id)); ?>">Price Lowest</a></li>
                    <li><a href="<?php echo e(route('category.highest', $category->id)); ?>"> Price Highest</a></li>
                    <li><a href="<?php echo e(route('category.alpha.lowest', $category->id)); ?>">Product A-Z</a></li>
                    <li><a href="<?php echo e(route('category.alpha.highest', $category->id)); ?>">Product Z-A</a></li>
                </ul>
            </div>


            <br>
            <p><?php echo e($count); ?> <?php echo e(str_plural('product', $count)); ?></p>

            <div class="row">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-12 wow slideInLeft" id="product-sub-container">
                        <div class="col-md-4 text-center hoverable">
                            <a href="<?php echo e(route('show.product', $product->product_name)); ?>">
                            <?php if($product->photos->count() === 0): ?>
                                    <img src="/store/src/public/images/no-image-found.jpg" alt="No Image Found Tag" id="Product-similar-Image">
                            <?php else: ?>
                                <?php if($product->featuredPhoto): ?>
                                    <img src="/store/<?php echo e($product->featuredPhoto->thumbnail_path); ?>" alt="Photo ID: <?php echo e($product->featuredPhoto->id); ?>" />
                                <?php elseif(!$product->featuredPhoto): ?>
                                    <img src="/store/<?php echo e($product->photos->first()->thumbnail_path); ?>" alt="Photo" />
                                <?php else: ?>
                                    N/A
                                <?php endif; ?>
                            <?php endif; ?>
                            </a>
                        </div>
                        <div class="col-md-5">
                            <a href="<?php echo e(route('show.product', $product->product_name)); ?>">
                            <h5 class="center-on-small-only"><?php echo e($product->product_name); ?></h5>
                            <h6 class="center-on-small-only">Brand: <?php echo e($product->brand->brand_name); ?></h6>
                            <p style="font-size: .9em;"><?php echo nl2br(str_limit($product->description, $limit = 200, $end = '...')); ?></p>
                            </a>
                        </div>
                        <div class="col-md-3 text-center">
                            <?php if($product->reduced_price == 0): ?>
                                $ <?php echo e($product->price); ?>

                                <br>
                            <?php else: ?>
                                <div class="text-danger list-price"><s>$ <?php echo e($product->price); ?></s></div>
                                $ <?php echo e($product->reduced_price); ?>

                            <?php endif; ?>
                            <br><br><br>
                                <form action="/store/cart/add" method="post" name="add_to_cart">
                                    <?php echo csrf_field(); ?>

                                    <input type="hidden" name="product" value="<?php echo e($product->id); ?>" />
                                    <input type="hidden" name="qty" value="1" />
                                    <button class="btn btn-default waves-effect waves-light">ADD TO CART</button>
                                </form>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        </div>  <!-- close container-fluid-->

    </div> <!-- close wrapper -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>