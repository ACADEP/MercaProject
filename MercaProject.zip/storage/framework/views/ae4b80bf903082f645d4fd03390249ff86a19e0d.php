<?php $__env->startSection("content"); ?>
<section class="content-header">
        <h1>
            Usuarios
        </h1> 
</section><br>

<div class="text-right">
    <button class="btn btn-success"  data-toggle="modal" data-target="#add_user"><i class="fa fa-plus-square" aria-hidden="true"></i> Agregar usuario</button>
</div>
<table class="table text-center">
    <thead>
            <tr>
                <th>Nombre</th>
                <th>Correo</th>
                <th>Rol</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr id="r-User<?php echo e($user->id); ?>">
                    <td><?php echo e($user->username); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e($user->getRoleDisplayNames()); ?></td>
                    <td>
                        <div class="form-inline">
                            <?php if($loop->iteration!=1): ?>
                            <button class="btn btn-danger btn-xs btn-delete-user" value="<?php echo e($user->id); ?>" data-toggle="tooltip" value="" data-placement="top" title="Eliminar"><i class="fa fa-minus-square" aria-hidden="true"></i></button>
                            
                            <form action="<?php echo e(route('show-update', $user)); ?>" method="get" style="display:inline;">
                                <button class="btn btn-info btn-xs" type="submit" data-toggle="tooltip" data-placement="top" title="Editar"><i class="fa fa-pencil-square" aria-hidden="true"></i></button>
                            </form>
                            <?php endif; ?>
                            
                        </div>   
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    
    </table>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('show-modal'); ?>
<?php if($errors->any()): ?>
    <script>
        $(function() {
            $('#add_user').modal('show');
        });
    </script>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('msg-success'); ?>
<?php if(Session::has("success")): ?>
<script>
 $.notify({
    // options
    message: '<strong><?php echo e(session("success")); ?></strong>' 
},{
    // settings
    type: 'success',
    delay:3000
});
</script>
<?php endif; ?>
<?php if(Session::has("flash")): ?>
<script>
 $.notify({
    // options
    message: '<strong><?php echo e(session("flash")); ?></strong>' 
},{
    // settings
    type: 'success',
    delay:3000
});
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('modal-add'); ?>
<div class="modal fade" id="add_user" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title text-center" id="exampleModalLongTitle">Agregar usuario</h1>
      </div>
      <div class="modal-body row">
      <?php if($errors->any()): ?>
        <div class="alert alert-danger alert-dismissible" role="alert">
            <ul><button type="button" class="close" data-dismiss="alert" aria-label="Close" ><span aria-hidden="true">&times;</span></button>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li style="list-style-type: none;"><?php echo e($error); ?> </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            </ul>
            
        </div>
        <?php endif; ?>
      <form action="<?php echo e(route('add-User')); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <div class="text-right" style="margin-right:45px;">
                <button class="btn btn-success" type="submit">Agregar</button>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
                </div>
        <div class="col-md-6 form-group">
        
            <h3>Datos personales</h3>
                <label for="username">Nombre de usuario</label>
                <input type="text" id="username" name="username" class="form-control" value="<?php echo e(old('username')); ?>">
                <label for="email">Correo</label>
                <input type="email" id="email" name="email" class="form-control" value="<?php echo e(old('email')); ?>">
                <label for="password">Contraseña</label>
                <input type="password" id="password" name="password" class="form-control">
                <label for="password_confirmed">Repite la Contraseña</label>
                <input type="password" id="password_confirmed" name="password_confirmation" class="form-control">
          
        </div>

            <div class="col-md-6 form-group">
                <h3>Roles y permisos</h3>
                <div class="col-md-12">
                <h4>Roles</h4>
                <?php if($roles->count() != 0): ?>

                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($loop->iteration!=1): ?>
                        <div class="col-md-6">
                        <input type="radio" name="roles[]" value="<?php echo e($role->name); ?>">
                            <?php echo e($role->display_name); ?>

                        <small class="text-muted"><?php echo e($role->permissions->pluck('display_name')->implode(', ')); ?></small>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                <span class="help-block">No existen roles</span>
                <?php endif; ?>
                </div>

                <br><hr>
                <div class="col-md-12">
               <h4>Permisos</h4>
                <?php if($permissions->count() != 0): ?>
            
                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6">
                    <input type="checkbox" name="permissions[]" value="<?php echo e($permission->name); ?>">
                        <?php echo e($permission->display_name); ?>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                <span class="help-block">No existen permisos</span>
                <?php endif; ?>
                </div>
                
            </div><!-- fin del col-md-6 -->
        </form>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin.dash", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>