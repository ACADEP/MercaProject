<!-- <div class="col-md-12 animated fadeInDown" id="brands">
        <div id="brand-caption">
            <div class="animated fadeInDown">
                <h3>Comprar por marcas</h3>
                <?php $__currentLoopData = $rand_brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <h6 id="random_brands"><a href="<?php echo e(url('brand', $rand->id)); ?>"><?php echo e($rand->brand_name); ?></a></h6>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
</div> -->
<h3>Comprar por marcas</h3>
<a href="<?php echo e(route('all.brands')); ?>">Ver todas</a>
<div id="carouselExampleControls2" class="carousel slide col-sm-12 col-md-12" data-ride="carousel" >
    <div class="carousel-inner">
      

      <div class="carousel-item active animated fadeInLeft col-sm-12 col-md-12">
          <img class="d-block w-100" src="/images/slider/brand-store.jpg" height="300px" alt="First slide">
          <div class="carousel-caption hidden-xs">
            <h1><strong>Comprar por marcas</strong></h1>
            <p class="lead">Compra con las mejores marcas!!</p>
          </div>
      </div>
    
        <?php $__currentLoopData = $rand_brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="carousel-item animated fadeInLeft col-sm-12 col-md-12">
                <a href="<?php echo e(url('brand', $rand->id)); ?>">
                    <div class="carousel-caption hidden-xs">
                        <h1><strong><span class="color"><?php echo e($rand->brand_name); ?></span></strong></h1>
                    </div>                
                    
                        <img class="rounded d-block" src="<?php echo e($rand->path); ?>" alt="Second slide" height="300px" >
                    
                </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        
      
    </div> 

</div>