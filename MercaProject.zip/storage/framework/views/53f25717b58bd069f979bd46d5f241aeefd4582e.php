<?php $__env->startSection('content'); ?>

<nav aria-label="breadcrumb" style="padding-top: 5px;">
    <ol class="breadcrumb breadcrumb-right-arrow">
        <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Inicio</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(url('/seller/admin')); ?>">Perfil</a></li>
        <li class="breadcrumb-item active" aria-current="page">Historial de Ventas</li>
    </ol>
</nav>          

<section class="content-header">
        <h1>
            Mi historial de ventas
        </h1>   
</section><br>

 <?php echo $__env->make('seller.partials.order-histories', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
    <table class="text-center table">
    <thead>
            <tr>
                <th>Imagen</th>
                <th>Nombre del producto</th>
                <th>Precio unt</th>
                <th>Cliente</th>
                <th>Fecha de la venta</th>
                <th>Cantidad</th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
        <?php if($seleHistories->count()>0): ?>
            <?php $__currentLoopData = $seleHistories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td ><img  src="<?php echo e($history->product->photos->first()->path); ?>"  height="30px"></td>
                    <td><?php echo e($history->product->product_name); ?></td>
                    <td>$<?php echo e(number_format($history->product->price, 2)); ?></td>
                    <td><?php echo e($history->client); ?></td>
                    <td><?php echo e($history->date); ?></td>
                    <td><?php echo e($history->amount); ?></td>
                    <td>$<?php echo e(number_format($history->total, 2)); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
        
        <?php endif; ?>
        </tbody>
    
    </table>
    <div class="text-center">
        <?php echo e($seleHistories->links()); ?>

    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('seller.dash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>