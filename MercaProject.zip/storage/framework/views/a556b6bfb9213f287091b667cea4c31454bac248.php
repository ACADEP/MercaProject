<!DOCTYPE html>
<html lang="es">
  <head>
    <meta charset="utf-8">
    <title>Cotización</title>
    <link rel="stylesheet" href="<?php echo e(asset('/css/InvoicePayment.css')); ?>" media="all" />
    <link href="<?php echo e(asset('/css/app.css')); ?>" rel="stylesheet">
  </head>
  <body>
    <?php  $now = new \DateTime(); ?>
    <header class="clearfix">
      <div id="logo">
          <div class="mercaLogo">
            <img src="<?php echo e(asset('/images/mercadata-footer.png')); ?>">
          </div>
            <div class="slogan">
                <strong><h3>MercaData</h3></strong>
                Tu tienda de tecnologia en línea 
            </div>
      </div>
      <h1>Cotización</h1>
      <div id="company" class="clearfix">
        <div><strong>Mercadata</strong></div>
        <div>Ignacio Allende,<br /> La Paz 23000, MX</div>
        <div>Tel: 612 122 5174</div>
        <div><a href="mailto:mercadata@acadep.com">mercadata@acadep.com</a></div>
      </div>
      <div id="project">
        <div><span><strong>Cliente</strong></span> <?php echo e(Auth::User()->customer->nombre); ?></div>
        <div><span><strong>Dirección</strong></span> <?php echo e($address->calle); ?>, <?php echo e($address->ciudad); ?> <?php echo e($address->cp); ?>, <?php echo e($address->estado); ?></div>
        <div><span><strong>Correo</strong></span> <a href="mailto:<?php echo e(Auth::User()->email); ?>"><?php echo e(Auth::User()->email); ?></a></div>
        <div><span><strong>Fecha</strong></span> <?php echo e($now->format('d-m-Y')); ?></div>
        <div><span><strong>Expiración</strong></span> <?php echo e($expiry); ?></div>
      </div>
    </header>
    <main>
      <table>
        <thead>
          <tr>
            <th class="service"><strong>Cantidad</strong></th>
            <th class="desc"><strong>Código</strong></th>
            <th><strong>Descripción</strong></th>
            <th><strong>Precio</strong></th>
            <th><strong>Total</strong></th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="service"><?php echo e($item->qty); ?></td>
                <td class="desc"><?php echo e($item->product->product_sku); ?></td>
                <td class="unit"><?php echo e($item->product->description); ?></td>
                <td class="qty">$<?php echo e(number_format($item->product_price, 2)); ?></td>
                <td class="total">$<?php echo e(number_format($item->total, 2)); ?></td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td colspan="4">Subtotal</td>
            <td class="total">$<?php echo e(number_format($subtotal, 2)); ?></td>
          </tr>
          <tr>
            <td colspan="4">IVA</td>
            <td class="total">$ 00.00</td>
          </tr>
          <tr>
            <td colspan="4">Costo de envío</td>
            <td class="total">$ 00.00</td>
          </tr>    
          <tr>
            <td colspan="4" class="grand total">Total</td>
            <td class="grand total">$<?php echo e(number_format($subtotal, 2)); ?></td>
          </tr>
        </tbody>
      </table>
      <div id="notices">
        
        <div class="notice">* Precios sujetos a cambio sin precio aviso.</div>
        <div class="notice">En espera de vernos favorecidos con su pedido, nos ponemos a sus ordenes para cualquier aclaración.</div>
      </div>
    </main>
    <footer>
        <div class="row data">
            <div class="address">
                <span>Dirección:</span><br>
                <strong>La Paz, BCS México</strong>
            </div>
            <div class="phone">
                <span>Teléfono: </span><br>
                <strong>612 1225174</strong>
            </div>
        </div>
    </footer>
  </body>
</html>