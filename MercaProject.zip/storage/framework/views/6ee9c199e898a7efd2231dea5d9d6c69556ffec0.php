<?php $__env->startSection('content'); ?>
<?php $ship_track=json_decode($track)  ?>
    <div class="text-center"> <h1>Detalles del envío</h1>  </div>
    <hr>
    <div class="text-left border" style="font-size: 25px;">
        Paquetería: <span class="label label-primary"><?php echo e($carrie); ?></span> <br><br>
        Estado del envío:<span class="label label-primary"><?php echo e($ship_track->shipment_status); ?> </span> <br><br>
        Número de guía: <span class="label label-primary"><?php echo e($ship_track->carrier_tracking_number); ?></span> <br><br>
        Fecha estimada de llegada: <span class="label label-primary"><?php echo e($ship_track->expected_delivery_date); ?> </span><br><br>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('customer.dash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>