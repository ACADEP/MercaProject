<?php $__env->startSection('content'); ?>

<nav aria-label="breadcrumb" class="pt-2">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Inicio</a></li>
        <li class="breadcrumb-item active" aria-current="page">Productos Destacados</li>
    </ol>
</nav>    

<h1 class="text-center">Productos Destacados</h1>

<div class="row col-12 col-sm-12 col-md-12 col-lg-12 mt-3">
    <?php echo $__env->make('partials.filters', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>

<br>

<div class="row col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12">
    
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-12 col-sm-6 col-md-4 col-lg-3 col-xl-3 wow slideInLeft mb-2 ml-3 pt-3 pb-2" id="product-sub-container" style="max-width: 23%;">
                <div class="row">
                    <div class="row col-3 col-sm-3 col-md-3 col-lg-3 pl-1" style="float: left; height: 80%;">
                            <span class="d-inline-block" tabindex="0" data-toggle="tooltip" title="Agregar al carrito" style="margin-left: 460%;">
                                <button class="btn btn-primary btn-rounded waves-effect waves-light btn-addcart" value="<?php echo e($product->id); ?>">
                                    <i class="material-icons" style="line-height: 2">add_shopping_cart</i><!--<i class="fa fa-plus" aria-hidden="true"></i>Agregar al carrito-->
                                </button>
                            </span>
                    </div>
                    <div class="row col-9 col-sm-9 col-md-9 col-lg-9 d-block pt-1 text-center hoverable">
                        <a href="<?php echo e(route('show.product', $product->product_name)); ?>">
                        <?php if($product->photos->count() === 0): ?>
                                <img src="/images/no-image-found.jpg" class="img-fluid" alt="No Image Found Tag" id="Product-similar-Image">
                        <?php else: ?>
                            <?php if($product->featuredPhoto): ?>
                                <img src="<?php echo e($product->featuredPhoto->thumbnail_path); ?>" class="img-fluid" alt="Photo ID: <?php echo e($product->featuredPhoto->id); ?>" width="100%" />
                            <?php elseif(!$product->featuredPhoto): ?>
                                <img src="<?php echo e($product->photos->first()->thumbnail_path); ?>" class="img-fluid" alt="Photo" />
                            <?php else: ?>
                                N/A
                            <?php endif; ?>
                        <?php endif; ?>
                        </a>
                    </div>            
                </div>
                <div class="text-center">
                    <a href="<?php echo e(route('show.product', $product->product_name)); ?>">
                    <h5 class="center-on-small-only"><?php echo e($product->product_name); ?></h5>
                    <h6 class="center-on-small-only">Marca: <?php echo e($product->brand->brand_name); ?></h6>
                    <p style="font-size: .9em;"><?php echo nl2br(str_limit($product->description, $limit = 200, $end = '...')); ?></p>
                    </a>
                </div>
                <div class="text-center">
                    <?php if($product->reduced_price == 0): ?>
                        $ <?php echo e($product->price); ?>

                        <br>
                    <?php else: ?>
                        <div class="text-danger list-price"><s>$ <?php echo e($product->price); ?></s></div>
                        <div class="blue-text light-300 medium-500" id="Product_Reduced-Price">$ <?php echo e(number_format(($product->price-$product->reduced_price), 2)); ?></div>
                    <?php endif; ?>
                    <input type="hidden" id="product_id<?php echo e($product->id); ?>" value="<?php echo e($product->id); ?>"/>
                    <input type="hidden" id="qty" value="1"/>
                    <input type="hidden" id="url" value="/cart/add">

                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
    
        
    
</div>
<div class="row justify-content-center mt-3 pl-5">
        <?php echo e($products->links()); ?>        
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>