<html>
    <head>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
       
        <link href="<?php echo e(asset('css/mdb.min.css')); ?>" rel="stylesheet">
        <link rel="stylesheet" href="<?php echo e(asset('/css/payments.css')); ?>">
       
        <link rel="stylesheet" href="<?php echo e(asset('/css/lity.css')); ?>">
        
        <!-- Added the main.css file that combines app.scss and app.css togather -->

        <!-- Scripts -->
        <script src="<?php echo e(asset('/js/app.js')); ?>" ></script>
        
        <link href="<?php echo e(asset('/css/app.css')); ?>" rel="stylesheet">
    </head>
<body>
<div class="container">
<?php  $now = new \DateTime(); ?>
<div class="row text-center">
        <div class="col-md-6 text-left"><img src="<?php echo e(asset('/images/mercadata-footer.png')); ?>" width="250px"></div>
        <div class="col-md-6 text-right">
            <strong><h3>MercaData</h3></strong>
            Tu tienda de tecnologia en línea <hr><br>
            <h4><strong>La Paz, BCS. </strong></h4>
            <h4><strong><?php echo e($now->format('d-m-Y')); ?></strong></h4>
        </div>
</div><!-- fin row 1-->
<br>
<div class="row text.center">
    <div class="col-md-6 text-left"><h2>Recibo de pago</h2>Cliente: <?php echo e(Auth::User()->username); ?></div>
    <div class="col-md-6 text-right"><strong><h3>Teléfono(s): 612 1225174</h3></strong></div>
</div><!-- fin row 2-->
<br>
<table class="table">
        <thead>
                <tr>
                    <th>Cantidad</th>
                    <th>Codigo</th>
                    <th>Nombre</th>
                    <th>Descripcion</th>
                    <th>Precio</th>
                    <th>SubTotal</th>
                </tr>
        </thead>
        <tbody>
                <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->qty); ?></td>
                        <td><?php echo e($item->product_sku); ?></td>
                        <td><?php echo e($item->product->product_name); ?></td>
                        <td><?php echo e($item->description); ?></td>
                        <td>$<?php echo e(number_format($item->product_price, 2)); ?></td>
                        <td>$<?php echo e(number_format($item->total, 2)); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <div class="row">
        <div class="text-left col-md-6">
            <strong>Subtotal con iva: </strong>$<?php echo e(number_format($subtotal, 2)); ?> <br>
            <strong>Costo de envio: </strong>$<?php echo e(number_format(0, 2)); ?> <br>
            <strong>Total: </strong>$<?php echo e(number_format($subtotal, 2)); ?> <br>
        </div>
        <div class="text-right col-md-6">
        <h5>Envio a:</h5>
            <div class="border">
                <strong>CP:</strong><?php echo e($address->cp); ?> <strong>Ciudad:</strong><?php echo e($address->ciudad); ?> <?php echo e($address->estado); ?> <br>
                <?php echo e($address->calle); ?> entre <?php echo e($address->calle2); ?> y <?php echo e($address->calle3); ?> colonia: <?php echo e($address->colonia); ?>

            </div>
        </div>
    </div>
    

<footer style="margin-top:100px;">
<div class="text-center">
    Atentamente <br>
    <strong>Mercadata</strong>
</div>
<div class="row">
    <div class="text-left col-md-6">
        <strong>La Paz,BCS México</strong>
    </div>

    <div class="text-right col-md-6">
        <strong>Telefono: 612 1225174</strong>
    </div>
</div>

</footer>

</div><!-- fin content-->
    


</body>
</html>




