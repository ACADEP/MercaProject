<?php $__env->startSection('content'); ?>

<nav aria-label="breadcrumb" class="pt-2">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Inicio</a></li>
        <li class="breadcrumb-item active" aria-current="page">Tiendas</li>
    </ol>
</nav>

<h1 class="shops text-center mt-3 mb-3">Tiendas Oficiales</h1>
<div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12" id="shops">
 
    <div class="row text-center" >
        <div>
            <div class="row">
                <?php $__currentLoopData = $shops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="col-sm-6 col-md-3 animated zoomIn" >
                        <a href="<?php echo e(route('shop', $shop->id)); ?>" style="text-decoration:none;">
                        <div class="card border-primary mb-3" style="max-width: 18rem; height: 200px;">
                            <div class="card-header header-color"><?php echo e($shop->name); ?></div>
                            <div class="card-body text-primary" id="shops-card">
                                <img class="img-fluid" src="<?php echo e($shop->path); ?>" alt="First slide" width="100%" height="200">
                            </div>
                        </div>
                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="row justify-content-center mt-3 pl-5">
                <?php echo e($shops->links()); ?>

            </div>             
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>