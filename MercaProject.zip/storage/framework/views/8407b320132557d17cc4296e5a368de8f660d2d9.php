<div class="row col-md-12">
    <nav aria-label="breadcrumb" class="pt-2">
        <ol class="breadcrumb">
            <?php if($URL[3] == '/'): ?> 
                <li class="breadcrumb-item"><a href="<?php echo e(url()->previous()); ?>">Inicio</a></li>
            <?php endif; ?>
            <?php if($URL[3] == '/cart'): ?> 
                <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Inicio</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(url()->previous()); ?>">Carrito</a></li>
            <?php endif; ?>
            <?php if($URL[2] == '/queries'): ?> 
                <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Inicio</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(url()->previous()); ?>">Busqueda</a></li>
            <?php endif; ?>
            <?php if($URL[0] == '/offers'): ?> 
                <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Inicio</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(url()->previous()); ?>">Productos Destacados</a></li>
            <?php endif; ?>
            <?php if($URL[1] == '/new-products'): ?> 
                <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Inicio</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(url()->previous()); ?>">Productos Nuevos</a></li>
            <?php endif; ?>
            <?php if($URL[5] == '/shop/1'): ?> 
                <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Inicio</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(url('/shops')); ?>">Tiendas</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(url()->previous()); ?>">Mercadata</a></li>
            <?php endif; ?>
            <?php if($URL[5] == '/shop/2'): ?> 
                <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Inicio</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(url('/shops')); ?>">Tiendas</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(url()->previous()); ?>">Apple</a></li>
            <?php endif; ?>
            <?php if($URL[5] == '/shop/3'): ?> 
                <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Inicio</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(url('/shops')); ?>">Tiendas</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(url()->previous()); ?>">Microsoft</a></li>
            <?php endif; ?>
            <?php if($URL[5] == '/shop/4'): ?> 
                <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Inicio</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(url('/shops')); ?>">Tiendas</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(url()->previous()); ?>">Microsistemas Californianos</a></li>
            <?php endif; ?>
            <?php if($URL[5] == '/shop/5'): ?> 
                <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Inicio</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(url('/shops')); ?>">Tiendas</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(url()->previous()); ?>">Pc Green</a></li>
            <?php endif; ?>
            <?php if($URL[5] == '/shop/6'): ?> 
                <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Inicio</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(url('/shops')); ?>">Tiendas</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(url()->previous()); ?>">Todo Pc</a></li>
            <?php endif; ?>
            <?php if($URL[5] == '/shop/7'): ?> 
                <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Inicio</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(url('/shops')); ?>">Tiendas</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(url()->previous()); ?>">Exacto</a></li>
            <?php endif; ?>
            <?php if($URL[4] == '/brand/1'): ?> 
                <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Inicio</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(url('/brands')); ?>">Marcas</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(url()->previous()); ?>">Hp</a></li>
            <?php endif; ?>
            <?php if($URL[4] == '/brand/2'): ?> 
                <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Inicio</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(url('/brands')); ?>">Marcas</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(url()->previous()); ?>">Epson</a></li>
            <?php endif; ?>
            <?php if($URL[4] == '/brand/3'): ?> 
                <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Inicio</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(url('/brands')); ?>">Marcas</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(url()->previous()); ?>">Microsoft</a></li>
            <?php endif; ?>
            <?php if($URL[4] == '/brand/4'): ?> 
                <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Inicio</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(url('/brands')); ?>">Marcas</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(url()->previous()); ?>">Seagate</a></li>
            <?php endif; ?>
            <?php if($URL[4] == '/brand/5'): ?> 
                <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Inicio</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(url('/brands')); ?>">Marcas</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(url()->previous()); ?>">Logitech</a></li>
            <?php endif; ?>
            <?php if($URL[4] == '/brand/6'): ?> 
                <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Inicio</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(url('/brands')); ?>">Marcas</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(url()->previous()); ?>">Samsung</a></li>
            <?php endif; ?>
            <?php if($URL[4] == '/brand/7'): ?> 
                <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Inicio</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(url('/brands')); ?>">Marcas</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(url()->previous()); ?>">Sony</a></li>
            <?php endif; ?>
            <?php if($URL[4] == '/brand/8'): ?> 
                <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Inicio</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(url('/brands')); ?>">Marcas</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(url()->previous()); ?>">Dell</a></li>
            <?php endif; ?>
            <?php if($URL[4] == '/brand/9'): ?> 
                <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Inicio</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(url('/brands')); ?>">Marcas</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(url()->previous()); ?>">Acer</a></li>
            <?php endif; ?>
            <?php if($URL[4] == '/brand/10'): ?> 
                <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Inicio</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(url('/brands')); ?>">Marcas</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(url()->previous()); ?>">Kodack</a></li>
            <?php endif; ?>
            <li class="breadcrumb-item active" aria-current="page"><?php echo e($product->product_name); ?></li>
        </ol>
    </nav>          
</div>