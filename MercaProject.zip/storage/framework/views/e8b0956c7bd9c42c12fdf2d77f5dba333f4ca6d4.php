<?php $__env->startSection('content'); ?>
    
    <?php echo $__env->make('partials.breadcrum', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
       
    <div class="col-md-12 row">
               
                <div class="col-md-8 gallery zoom-container">
                    <?php if($product->photos->count() == 0): ?>
                        <p>No hay imagenes de este producto.</p><br>
                        <img src="/images/no-image-found.jpg" alt="No Image Found Tag" id="Product-similar-Image">
                    <?php else: ?>
                        <?php $__currentLoopData = $product->photos->slice(0, 8); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-xs-6 col-sm-4 col-md-4 gallery_image text-center" style="float:left;" >
                                <a href="<?php echo e($photo->path); ?>" data-lity>
                                    <img src="<?php echo e($photo->thumbnail_path); ?>"  alt="Photo ID: <?php echo e($photo->id); ?>" data-id="<?php echo e($photo->id); ?>" class="img-thumbnail">
                                </a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                   
                </div>
                
                <div class="col-md-4">
                    <h5 id="Product_Name"><?php echo e($product->product_name); ?></h5>
                    <p id="Product_Brand">Marca: <?php echo e($product->brand->brand_name); ?></p>
                    <br>
                    <?php if($product->reduced_price == 0): ?>
                        <div class="light-300 black-text medium-500" id="Product_Reduced-Price">$ <?php echo e($product->price); ?></div>
                        <br>
                    <?php else: ?>
                        <div class="discount light-300 black-text medium-500" id="Product_Reduced-Price"><s style="color: red">$ <?php echo e($product->price); ?><i class="fa fa-tag pl-1" aria-hidden="true"></i></s></div>
                        <div class="green-text medium-500" id="Product_Reduced-Price">$ <?php echo e($product->price-$product->reduced_price); ?></div>
                    <?php endif; ?>
                    <hr>

                    <?php if($product->product_qty == 0): ?>
                        <h5 class="text-center red-text">Agotado</h5>
                        <p class="text-center"><b>Disponible: <?php echo e($product->product_qty); ?></b></p>
                    <?php else: ?>
                            <input type="hidden" name="product" value="<?php echo e($product->id); ?>" />
                           
                            <input type="hidden" id="product_id<?php echo e($product->id); ?>" value="<?php echo e($product->id); ?>"/>
                            <input type="hidden" id="qty" value="1"/>
                            <input type="hidden" id="url" value="<?php echo e(url('/cart/add')); ?>">
                            <span class="d-inline-block" tabindex="0" data-toggle="tooltip" title="Agregar al carrito">
                                <button class="btn btn-success btn-addcart" value="<?php echo e($product->id); ?>">
                                        <i class="material-icons" style="line-height: 2">add_shopping_cart</i><!--<i class="fa fa-plus" aria-hidden="true"></i>Agregar al carrito-->
                                </button>
                            </span>
                            <br><br>

                            <p><b>Disponible: <?php echo e($product->product_qty); ?></b></p>
                            <img src="<?php echo e(route('QRCode')); ?>" width="200" heigth="200">
                            
                            
                    <?php endif; ?>

                </div>

            </div>  <!-- close col-md-12 -->

            <!-- Especificacones y descripcion -->
            <div class="row">
                <div  class="col-md-6" >
                <h2>Descripción</h2>
                    <?php echo $product->description; ?>

                </div>
                <div  class="col-md-6" >
                <h2>Especificaciones</h2>
                    <?php echo $product->product_spec; ?>

                </div>
            </div>
            <br><br>

            <div class="row">

                <h3 class="col-md-12">Productos similares</h3><br>

                <?php $__currentLoopData = $similar_product->slice(0, 4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $similar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-xs-6 col-md-2" id="Similar-Product-Sub-Container" >
                        <a href="<?php echo e(route('show.product', $similar->product_name)); ?>">
                            <?php if($similar->photos->count() === 0): ?>
                                <p id="Similar-Title"><?php echo e(str_limit($similar->product_name, $limit = 28, $end = '...')); ?></p>
                                <img src="/images/no-image-found.jpg" alt="Imagen no encontrada" id="Product-similar-Image">
                            <?php else: ?>
                                <?php if($similar->featuredPhoto): ?>
                                    <p id="Similar-Title"><?php echo e(str_limit($similar->product_name, $limit = 28, $end = '...')); ?></p>
                                    <img src="<?php echo e($similar->featuredPhoto->thumbnail_path); ?>" alt="Photo ID: <?php echo e($similar->featuredPhoto->id); ?>" id="Product-similar-Image" />
                                <?php elseif(!$similar->featuredPhoto): ?>
                                    <p id="Similar-Title"><?php echo e($similar->product_name); ?></p>
                                    <img src="<?php echo e($similar->photos->first()->thumbnail_path); ?>" alt="Photo" id="Product-similar-Image" />
                                <?php else: ?>
                                    N/A
                                <?php endif; ?>
                            <?php endif; ?>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>

</div>  <!-- close col-md-12 -->


      

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>