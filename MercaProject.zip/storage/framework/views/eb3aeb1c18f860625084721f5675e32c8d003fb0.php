<html>
<head>
    <link href="<?php echo e(asset('/css/app.css')); ?>" rel="stylesheet">
</head>
<body>
    <div><img src="<?php echo e(asset('/images/mercadata-footer.png')); ?>" width="250px"></div>
    <?php $now = new \DateTime(); ?>
    <div class="text-right"><?php echo e($now->format('d-m-Y h:i')); ?></div>
    <table class="table">
       <?php $totalCart=0;?>
        <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Precio</th>
                    <th>Cantidad</th>
                    <th>SubTotal</th>
                    
                </tr>
        </thead>
        <tbody>
            <?php if(Auth::check()): ?>
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->product->product_name); ?></td>
                        <td>$<?php echo e(number_format($item->product_price, 2)); ?></td>
                        <td><?php echo e($item->qty); ?></td>
                        <td>$<?php echo e(number_format($item->total, 2)); ?></td>
                        <?php $totalCart+=$item->total; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <?php $total_price=$item->price-$item->reduced_price; ?>
                    <td><?php echo e($item->product_name); ?></td>
                    <td>$<?php echo e(number_format($total_price, 2)); ?></td>
                    <td><?php echo e($item->qty); ?></td>
                    <td>$<?php echo e(number_format(($total_price*$item->qty), 2)); ?></td>
                    <?php $totalCart+=$total_price*$item->qty; ?>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
           
        </tbody>
    </table>
    <br>
    <div id="total">Su total es: $<?php echo e(number_format($totalCart, 2)); ?></div>        
    
        
 
</body>

</html>





