<!DOCTYPE html>
<html lang="es">
  <head>
    <meta charset="utf-8">
    <title>Carrito de compras</title>
    <link href="<?php echo e(asset('/css/app.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('/css/InvoicePayment.css')); ?>" media="all" />
  </head>
  <body>
    <?php  $now = new \DateTime(); ?>
    <header class="clearfix">
      <div id="logo">
          <div class="mercaLogo">
            <img src="<?php echo e(asset(config('configurations.general.main_logo'))); ?>">
          </div>
            <div class="slogan font">
                <strong><h3><?php echo e(config('configurations.general.store_name')); ?></h3></strong>
                <?php echo e(config('configurations.mk.slogan')); ?>

            </div>
      </div>
      <h1 class="tittle font">Carrito de compras</h1>

      <div class="row mb-3" id="dates">
        <div class="col-sm-6 col-md-6" id="project">
          <div><span><strong>Cliente</strong></span> <?php echo e(Auth::check() ? Auth::user()->username : 'visitante'); ?></div>
          <div><span><strong>Correo</strong></span><?php echo e(Auth::check() ? Auth::user()->email : 'visitante'); ?></div>
          <div><span><strong>Fecha</strong></span> <?php echo e($now->format('d-m-Y')); ?></div>
        </div>
    
        <div class="col-sm-6 col-md-6 text-right" id="company" class="clearfix font">
          <div><strong><?php echo e(config('configurations.general.store_name')); ?></strong></div>
          <div><?php echo e(config('configurations.company.direction_1')); ?>,<br /> 
                <?php echo e(config('configurations.company.city')); ?> <?php echo e(config('configurations.company.postal_code')); ?>, 
                <?php echo e(config('configurations.company.country_code')); ?></div>
          <div>Tel:  <?php echo e(config('configurations.company.phone')); ?></div>
          <div><a href="mailto:mercadata@acadep.com">mercadata@acadep.com</a></div>
        </div>  
      </div>

      <div class="row mt-5"></div>
    </header>
    <main>
    <table class="table text-center">
       <?php $totalCart=0;?>
        <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Precio</th>
                    <th>Cantidad</th>
                    <th>SubTotal</th>
                </tr>
        </thead>
        <tbody>
            <?php if(Auth::check()): ?>
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($item->product->product_name); ?></td>
                        <td>$<?php echo e(number_format($item->product_price, 2)); ?></td>
                        <td><?php echo e($item->qty); ?></td>
                        <td>$<?php echo e(number_format($item->total, 2)); ?></td>
                        <?php $totalCart+=$item->total; ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <?php $total_price=$item->real_price ?>
                    <td><?php echo e($item->product_name); ?></td>
                    <td>$<?php echo e(number_format($total_price, 2)); ?></td>
                    <td><?php echo e($item->qty); ?></td>
                    <td>$<?php echo e(number_format(($total_price*$item->qty), 2)); ?></td>
                    <?php $totalCart+=$total_price*$item->qty; ?>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            
        </tbody>

    </table>
    <div class="text-right">
           <strong>Total:</strong>  $<?php echo e(number_format($totalCart, 2)); ?>

    </div>
      <div id="notices">
      <div><strong>Forma de pago: En espera</strong></div>
      
        <div class="notice"><?php echo e(config('configurations.mk.information_final_2')); ?></div>
        <div class="notice"><?php echo e(config('configurations.mk.information_final')); ?></div>
      </div>
    </main>
    <footer>
        <div class="row data">
            <div class="address">
                <span>Dirección:</span><br>
                <strong><?php echo e(config('configurations.company.city')); ?> <?php echo e(config('configurations.company.postal_code')); ?>, 
                <?php echo e(config('configurations.company.country_code')); ?></strong>
            </div>
            <div class="phone">
                <span>Teléfono: </span><br>
                <strong> <?php echo e(config('configurations.company.phone')); ?></strong>
            </div>
        </div>
    </footer>
  </body>
</html>





