
<div class="col-md-12" id="new_product">
<h4 class="text-left animated zoomIn" id="title-product">Nuevos productos<a href="<?php echo e(route('all.new-products')); ?>" class="ml-2" style="font-size: 15px;">Ver todos</a></h4>
    <div class="text-center row">
        <div class="container-fluid" id="Index-Main-Container">
            <div id="featured-products-sub-container">
                <div class="row col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 ">
                    <?php echo $__env->make('pages.utils.product-card', ["data"=>$new], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>
            </div>  
        </div>
    </div>
</div>



