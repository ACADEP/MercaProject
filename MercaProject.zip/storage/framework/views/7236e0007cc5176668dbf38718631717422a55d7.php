<?php $__env->startSection('content'); ?>

<style>
#menu * { list-style:none;}
#menu li{ line-height:180%;}
#menu li a{color:#222; text-decoration:none;}
#menu li a:before{ content:"\025b8"; color:#ddd; margin-right:4px;}
#menu input[name="list"] {
	position: absolute;
	left: -1000em;
	}
#menu label:before{ content:"\025b8"; margin-right:4px;}
#menu input:checked ~ label:before{ content:"\025be";}
#menu .interior{display: none;}
#menu input:checked ~ ul{display:block;}
</style>


<div id="shops">
    <h2 class="text-left" id="title-shop"># Tienda oficial</h2>
    <div class="col-12 text-center" >
        <div class="card border-primary mb-3 text-center">
            <img class="d-block w-100" src="<?php echo e(asset('/images/Shops/Apple.jpeg')); ?>" alt="First slide">
        </div>
    </div>

    <div class="row flex-lg-nowrap">
        <div class="col-6 col-md-3" id="order">
            <?php echo $__env->make('shop.filter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <div class="row">
            <?php echo $__env->make('pages.partials.featured', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>