<?php $__env->startSection('content'); ?>

    <!-- <?php echo $__env->make('pages.partials.side-nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> -->
    <?php echo $__env->make('pages.partials.carousel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- <?php echo $__env->make('pages.partials.mobile-header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> -->

    <!-- Button to toggle side-nav -->
    <!-- <a href="#menu-toggle" class="btn btn-default" id="menu-toggle"><i class="fa fa-bars fa-5x"></i></a> -->
    
    <!-- Featured Products section -->
    <?php echo $__env->make('pages.partials.featured', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- Oficcials stores section -->
    <?php echo $__env->make('pages.partials.stores', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- New Products section -->
    <?php echo $__env->make('pages.partials.new', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- Buy for brands -->
    <?php echo $__env->make('pages.partials.brands', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- close wrapper -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>