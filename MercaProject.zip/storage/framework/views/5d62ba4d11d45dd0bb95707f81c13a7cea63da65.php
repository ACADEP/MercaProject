<?php $__env->startSection('content'); ?>

   
    <?php echo $__env->make('pages.partials.carousel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
    <!-- Featured Products section -->
    <?php echo $__env->make('pages.partials.featured', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- Selled Products section -->
    <?php echo $__env->make('pages.partials.selled-products', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    

    <!-- New Products section -->
    <?php echo $__env->make('pages.partials.new', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- Buy for brands -->
    <?php echo $__env->make('pages.partials.brands', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- close wrapper -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>