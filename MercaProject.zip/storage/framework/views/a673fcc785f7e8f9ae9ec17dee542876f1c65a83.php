<?php $__env->startSection('content'); ?>

<nav aria-label="breadcrumb" class="pt-2">
    <ol class="breadcrumb breadcrumb-right-arrow">
        <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Inicio</a></li>
        <li class="breadcrumb-item active" aria-current="page">Tiendas</li>
    </ol>
</nav>

<h1 class="brands text-center mt-3 mb-3">Tiendas Oficiales</h1>
<div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12" id="brands">
 
    <div class="row text-center" >
            <div class="row">
                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="col-sm-6 col-md-3 animated zoomIn">
                        <a href="<?php echo e(route('brand', $brand->id)); ?>" style="text-decoration:none;">
                            <div class="card mb-3" style="max-width: 18rem; height: 290px;">
                                <div class="card-header header-color"><?php echo e($brand->brand_name); ?></div>
                                <div class="card-body text-primary" id="brand-card">
                                    <img class="img-fluid" src="<?php echo e($brand->path); ?>" alt="First slide" width="100%" height="200">
                                </div>
                            </div>
                        </a>
                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="row justify-content-center mt-3 pl-5">
                <?php echo e($brands->links()); ?>

            </div>             
    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>