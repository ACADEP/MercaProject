<?php $__env->startSection('content'); ?>

<h1 class="brand mt-3 mb-3">Marcas</h1>
<div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-12" id="breads">
 
    <div class="text-center" >
        <div id="featured-brands-sub-container">
            <div class="row">
                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="col-sm-6 col-md-3 animated zoomIn" >
                        <a href="<?php echo e(route('brand', $brand->id)); ?>" style="text-decoration:none;">
                        <div class="card border-primary mb-3" style="max-width: 18rem; height: 290px;">
                            <div class="card-header"><?php echo e($brand->brand_name); ?></div>
                            <div class="card-body text-primary" id="brand-card">
                                <img class="img-fluid" src="<?php echo e($brand->path); ?>" alt="First slide" width="100%" height="200">
                            </div>
                        </div>
                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>