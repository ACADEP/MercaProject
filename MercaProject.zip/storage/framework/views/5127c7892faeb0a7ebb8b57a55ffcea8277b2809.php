<?php $__env->startSection('content'); ?>

<nav aria-label="breadcrumb" style="padding-top: 5px;">
    <ol class="breadcrumb breadcrumb-right-arrow">
        <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Inicio</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(url('/customer/profile')); ?>">Perfil</a></li>
        <li class="breadcrumb-item active" aria-current="page">Datos Personales</li>
    </ol>
</nav>    

<section class="content-header">
    <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
        <h2>
            Datos Personales 
        </h2> 
    </div>
    <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
        <h2>
            Dirección de Facturación 
        </h2> 
    </div>    
</section><br>     
<div class="text-center" style="margin-right: 90%; padding-bottom: 20px;">
    <?php if($userpersonal != null): ?>
        <a type="button" href="<?php echo e(route('customer.personal.showUpdate', $userpersonal->id)); ?>" class="btn btn-success add" ><i class="fa fa-plus-square" aria-hidden="true"></i> Actualizar</a>
    <?php else: ?>
        <button class="btn btn-success add"  data-toggle="modal" data-target="#add_personaldate"><i class="fa fa-plus-square" aria-hidden="true"></i> Agregar</button>
    <?php endif; ?>
</div>
<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
    <?php if($userpersonal != null): ?> 
        <label class="lead" for="">Nombre: <?php echo e($userpersonal->nombre); ?></label><br>
        <label class="lead" for="">Apellidos: <?php echo e($userpersonal->apellidos); ?></label><br>
        <label class="lead" for="">Telefono: <?php echo e($userpersonal->telefono); ?></label><br>
    <?php else: ?> 
        <label class="lead" for="">Nombre: </label><br>
        <label class="lead" for="">Apellidos: </label><br>
        <label class="lead" for="">Telefono: </label><br>
    <?php endif; ?>
</div>
<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
    <?php if($userpersonal != null): ?> 
        <label class="lead" for="">Nombre o razón social: <?php echo e($userpersonal->razonSocial); ?></label><br>
        <label class="lead" for="">Tipo de facturación: <?php echo e($userpersonal->tipoFacturacion); ?></label><br>
        <label class="lead" for="">RFC: <?php echo e($userpersonal->rfc); ?></label><br>
        <label class="lead" for="">Calle: <?php echo e($userpersonal->calle); ?></label><br>
        <label class="lead" for="">N° Exterior: <?php echo e($userpersonal->numExterior); ?></label><br>
        <label class="lead" for="">N° Interior: <?php echo e($userpersonal->numInterior); ?></label><br>
        <label class="lead" for="">Código Postal: <?php echo e($userpersonal->cp); ?></label><br>
        <label class="lead" for="">Estado: <?php echo e($userpersonal->estado); ?></label><br>
        <label class="lead" for="">Ciudad: <?php echo e($userpersonal->ciudad); ?></label><br>
        <label class="lead" for="">Colonia: <?php echo e($userpersonal->colonia); ?></label><br>
        <label class="lead" for="">Razón CFDI: <?php echo e($userpersonal->cfdi); ?></label><br>
    <?php else: ?> 
        <label class="lead" for="">Nombre o razón social: </label><br>
        <label class="lead" for="">Tipo de facturación: </label><br>
        <label class="lead" for="">RFC: </label><br>
        <label class="lead" for="">Calle: </label><br>
        <label class="lead" for="">N° Exterior: </label><br>
        <label class="lead" for="">N° Interior: </label><br>
        <label class="lead" for="">Código Postal: </label><br>
        <label class="lead" for="">Estado: </label><br>
        <label class="lead" for="">Ciudad: </label><br>
        <label class="lead" for="">Colonia: </label><br>
        <label class="lead" for="">Razón CFDI: </label><br>
    <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('mostrar-modal'); ?>
    <?php if($errors->any()): ?>
        <script>
            $('.add').click(function(){
            // $(function() {
                $('#add_personaldate').modal('show');
            });
            $('.update').click(function(){
                $('#update_personaldate').modal('show');
            });
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('customer.dash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>