<?php $__env->startSection('content'); ?>

    <div class="container-fluid" id="Login-Register-Container">
        <div class="row justify-content-center">
            <div class="col-12 col-sm-6 col-md-4 col-sm-offset-3 col-md-offset-4">
                <div class="card" id="Login-Register-Panel">
                    <div class="card-body">
                    <?php if(session('flash')): ?>
                        <div class="alert alert-success">
                            <?php echo e(session('flash')); ?>

                        </div>
                    <?php endif; ?>
                        <h4 class="text-center" id="log-in">Registrarse</h4>
                        <form class="form-horizontal" role="form" method="POST" action="<?php echo e(route('auth.register')); ?>">
                            <?php echo csrf_field(); ?>


                            <div class="form-group<?php echo e($errors->has('username') ? ' has-error' : ''); ?>">
                                <div class="col-md-12 col-md-offset-1">
                                    <input type="text" class="form-control" name="username" value="<?php echo e(old('username')); ?>" placeholder="Usuario">
                                    <?php if($errors->has('username')): ?>
                                        <span class="form-text">
                                        <strong><?php echo e($errors->first('username')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('account') ? ' has-error' : ''); ?>">
                                <div class="col-md-12 col-md-offset-1">
                                    <select class="form-control" id="SelectAccount" name="account" value="<?php echo e(old('account')); ?>">
                                        <option value="0" selected>Cliente</option>
                                        <option value="1">Vendedor</option>
                                    </select>
                                    <?php if($errors->has('account')): ?>
                                        <span class="form-text">
                                        <strong><?php echo e($errors->first('account')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                                <div class="col-md-12 col-md-offset-1">
                                    <input type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" placeholder="Correo">
                                    <?php if($errors->has('email')): ?>
                                        <span class="form-text">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                                <div class="col-md-12 col-md-offset-1">
                                    <input type="password" class="form-control" name="password" placeholder="Contraseña">
                                    <?php if($errors->has('password')): ?>
                                        <span class="form-text">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group<?php echo e($errors->has('password_confirmation') ? ' has-error' : ''); ?>">
                                <div class="col-md-12 col-md-offset-1">
                                    <input type="password" class="form-control" name="password_confirmation" placeholder="Confirmar Contraseña">
                                    <?php if($errors->has('password_confirmation')): ?>
                                        <span class="form-text">
                                        <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="col-md-12 col-md-offset-3 text-center">
                                <input type="hidden" id="registerCookie" name="cookieProductos">
                                <script>document.getElementById("registerCookie").value=Cookies.get("productos");</script>
                                    <br><button type="submit" class="btn btn-default btn-rounded waves-effect waves-light btn-block">Registrarse</button>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="col-md-12 col-md-offset-3 text-center">
                                    <a href="<?php echo e(url('/login')); ?>" id="Sign-up" class="btn btn-default btn-rounded waves-effect waves-light btn-block">Inicia Sesión</a>
                                </div>
                            </div>

                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>