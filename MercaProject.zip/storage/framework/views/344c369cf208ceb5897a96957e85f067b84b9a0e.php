<?php $__env->startSection('content'); ?>

    <div id="wrapper">

        <?php echo $__env->make('pages.partials.side-nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <!-- Button to toggle side-nav -->
        <a href="#menu-toggle" class="btn btn-default" id="menu-toggle"><i class="fa fa-bars fa-5x"></i></a>

        <div class="container-fluid">

            <div class="col-md-12">

                <h4 class="text-center">Your Orders</h4><br>

                <div class="menu">
                    <div class="accordion">
                        <?php if($orders->count() == 0): ?>
                            You have no orders
                        <?php else: ?>
                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="accordion-group">
                                    <div class="accordion-heading" id="accordion-group">
                                        <a class="accordion-toggle" data-toggle="collapse" href="#order<?php echo e($order->id); ?>">Order #<?php echo e($order->id); ?> - <?php echo e(prettyDate($order->created_at)); ?></a>
                                    </div>
                                    <div id="order<?php echo e($order->id); ?>" class="accordion-body collapse">
                                        <div class="accordion-inner">
                                            <table class="table table-striped table-condensed">
                                                <thead>
                                                <tr>
                                                    <th>
                                                        Product
                                                    </th>
                                                    <th>
                                                        Quantity
                                                    </th>
                                                    <th>
                                                        Product Price
                                                    </th>
                                                    <th>
                                                        Total
                                                    </th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                <?php $__currentLoopData = $order->orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><a href="<?php echo e(route('show.product', $orderitem->product_name)); ?>"><?php echo e($orderitem->product_name); ?></a></td>
                                                        <td><?php echo e($orderitem->pivot->qty); ?></td>
                                                        <td>
                                                            <?php if($orderitem->pivot->reduced_price == 0): ?>
                                                                $<?php echo e($orderitem->pivot->price); ?>

                                                            <?php else: ?>
                                                               $<?php echo e($orderitem->pivot->reduced_price); ?>

                                                            <?php endif; ?>
                                                        </td>
                                                        <td>
                                                            <?php if($orderitem->pivot->total_reduced == 0): ?>
                                                                $<?php echo e($orderitem->pivot->total); ?>

                                                            <?php else: ?>
                                                                $<?php echo e($orderitem->pivot->total_reduced); ?>

                                                            <?php endif; ?>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><b>Customer Info</b></td>
                                                    <td><?php echo e($order->first_name); ?> <?php echo e($order->last_name); ?></td>
                                                    <td></td>
                                                    <td></td>
                                                </tr>
                                                <tr>
                                                    <td><b>Shipping Address</b></td>
                                                    <td><?php echo e($order->address); ?><br><?php echo e($order->city); ?>, <?php echo e($order->state); ?></td>
                                                    <td><b>Total</b></td>
                                                    <td><b>$<?php echo e($order->total); ?></b></td>
                                                </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                </div>

            </div>

        </div>  <!-- close container-fluid -->

    </div>  <!-- close wrapper -->


<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>