<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4 col-lg-3 col-xs-6 col-sm-6  wow animated zoomIn " id="product-sub-container">
        <div class="text-center" style="margin-bottom:10px;"> <span class="badge badge-primary" style="font-size:15px;"><?php echo e($product->brand!=null ? $product->brand->brand_name : 'SinMarca'); ?></span> </div>
            <div class="row">
                
                <div class="col-md-12 text-center hoverable" style="width:100%;">
                    <a class="link-products" href="<?php echo e(route('show.product', $product->id."-".$product->product_name)); ?>" style="text-decoration: none;">
                    <?php if($product->photos->count() == 0): ?>
                            <img src="/images/no-image-found.jpg" class="img-fluid" alt="No Image Found Tag">
                    <?php else: ?>
                   
                        <?php if($product->featuredPhoto): ?>
                            <img src="<?php echo e($product->photos()->first()->path); ?>" onerror="this.onerror=null; this.src='/images/no-image-found.jpg'" class="img-fluid" alt="Photo ID: <?php echo e($product->featuredPhoto->id); ?>" width="100%" />
                        <?php elseif(!$product->featuredPhoto): ?>
                            <img src="<?php echo e($product->photos()->first()->path); ?>" onerror="this.onerror=null; this.src='/images/no-image-found.jpg'" class="img-fluid" alt="Photo" />
                        <?php else: ?>
                            N/A
                        <?php endif; ?>
                    <?php endif; ?>
                    </a>
                </div>
            </div>
            <div class="text-center">
                <?php
                    $acorName = substr($product->product_name, 0, 25);
                    $acorDesc = substr($product->description, 0, 25);
                ?>
                <a class="link-products" href="<?php echo e(route('show.product', $product->id)); ?>" style="text-decoration: none;">
                <h5 class="center-on-small-only"><?php echo e($acorName); ?></h5>
                <p style="font-size: .9em;"><?php echo e(substr($product->description,0,50)); ?></p>
                <p>SKU: <?php echo e($product->product_sku); ?></p>
                </a>
            </div>
            <div class="text-center">
                <?php if($product->reduced_price == 0): ?>
                    <i class="fa fa-tag" style="color: green" aria-hidden="true"></i> $ <?php echo e(number_format($product->real_price, 2)); ?>

                    <br>
                <?php else: ?>
                    <div class="text-danger list-price"><s style="color: red">$ <?php echo e(number_format($product->price*1.16, 2)); ?><i class="fa fa-tag" aria-hidden="true"></i></s></div>
                    <div class="blue-text light-300 medium-500" id="Product_Reduced-Price">$ <?php echo e(number_format($product->real_price, 2)); ?></div>
                <?php endif; ?>
                    <input type="hidden" id="product_id<?php echo e($product->id); ?>" value="<?php echo e($product->id); ?>"/>
                    <input type="hidden" id="qty" value="1"/>
                    <input type="hidden" id="url" value="/cart/add">
                    
            </div>
            <div class="col-md-12 text-center" style="width:100%;">
                    <div class="text-center">
                        <?php if($product->product_qty > 0): ?>
                            <button class="btn btn-primary btn-sm btn-addcart"  data-toggle="tooltip" title="Agregar al carrito" value="<?php echo e($product->id); ?>">
                                <i class="fa fa-shopping-cart"></i>
                            </button>
                        <?php else: ?>
                            <span class="badge badge-danger">Agotado</span><br>
                        <?php endif; ?>
                        <?php if(Auth::check()): ?>
                            <button  class="btn btn-warning btn-sm btn-favorite"  data-toggle="tooltip" title="Agregar a favoritos"  data-toggle="tooltip" title="Agregar a favoritos" value="<?php echo e($product->id); ?>">
                                <i class="fa fa-heart" aria-hidden="true"></i>
                            </button>
                        <?php endif; ?>
                    </div>
                </div>
        </div>
       
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>