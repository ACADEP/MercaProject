<?php $__env->startSection('content'); ?>

<div class="row col-12 col-sm-12 col-md-12 col-lg-12">
    <div><h1 class="address ml-5">Direcciones</h1></div>
    <div class="col-12 col-sm-12 col-md-12 col-lg-12">
        
    </div>
    <div class="col-12 col-sm-12 col-md-12 col-lg-12">
        <a href="#AgregarDirección" class="btn btn-success text-center"><i class="fa fa-plus" aria-hidden="true"></i> Agregar Dirección</a>
    </div>    
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('customer.dash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>