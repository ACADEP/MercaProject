<?php $__env->startSection('content'); ?>

<style>
.dlk-radio input[type="radio"],
.dlk-radio input[type="checkbox"] 
{
	margin-left:-99999px;
	display:none;
}
.dlk-radio input[type="radio"] + .fa ,
.dlk-radio input[type="checkbox"] + .fa {
     opacity:0.15
}
.dlk-radio input[type="radio"]:checked + .fa,
.dlk-radio input[type="checkbox"]:checked + .fa{
    opacity:1
}
</style>

<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>

<section class="content-header">
        <h1>
            Direcciones 
        </h1> 
</section><br>     
<div class="text-center" style="margin-right: 14%; padding-bottom: 20px;">
    <button class="btn btn-success"  data-toggle="modal" data-target="#add_address"><i class="fa fa-plus-square" aria-hidden="true"></i> Agregar</button>
</div>
<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
    <?php if($useraddresses != null): ?>
        <?php
            $id = 1;
        ?>
        <!-- <form action="#" method="POST"> -->
            <div class="panel-group col-xs-6 col-sm-6 col-md-6 col-lg-6" id="accordion" style="width: 100%;" role="tablist" aria-multiselectable="true" >
                
                
                
                
                
                
                
                
                
                <?php $__currentLoopData = $useraddresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="panel panel-default" id="address<?php echo e($address->id); ?>">
                            <div class="panel-heading" role="tab" id="heading<?php echo e($id); ?>">
                                <h4 class="panel-title" style="float: left;">
                                    <div class="dlk-radio btn-group" style="margin-bottom: 10px;">
                                        <?php if($address->activo == 1): ?>
                                            <label class="btn btn-xs btn-success btn-validate">
                                            <input name="choices[1]" class="form-control activo" type="radio" value="<?php echo e($address->id); ?>" defaultchecked="checked" checked>
                                                <i class="fa fa-check glyphicon glyphicon-ok icon-validate"></i>
                                            </label>
                                        <?php else: ?>
                                            <label class="btn btn-xs btn-success">
                                                <input name="choices[1]" class="form-control btn-click activo" type="radio" value="<?php echo e($address->id); ?>" defaultchecked="checked">
                                                <i class="fa fa-times glyphicon glyphicon-ok icon-click"></i>
                                            </label>
                                        <?php endif; ?>
                                         
                                    </div>
                                    <a class="collapsed lead" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse<?php echo e($id); ?>" aria-expanded="false" aria-controls="collapse<?php echo e($id); ?>">
                                        <?php echo e($address->calle); ?>

                                    </a>
                                </h4>
                                <div class="form-inline" style="margin-left: 88%;">
                                    <button class="btn btn-danger btn-xs btn-delete" data-toggle="tooltip" value="<?php echo e($address->id); ?>" data-placement="top" title="Eliminar"><i class="fa fa-minus-square" aria-hidden="true"></i></button>
                                    <a type="button" href="<?php echo e(route('customer.address.showUpdate', $address->id)); ?>" class="btn btn-info btn-xs" data-toggle="tooltip" data-placement="top" title="Actualizar"><i class="fa fa-pencil-square" aria-hidden="true"></i></a>
                                </div> 
                            </div>
                            <div id="collapse<?php echo e($id); ?>" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading<?php echo e($id); ?>">
                                <div class="panel-body">
                                    <label class="lead" for="">Calle principal: <?php echo e($address->calle); ?></label><br>
                                    <label class="lead" for="">Ciudad: <?php echo e($address->ciudad); ?></label><br>
                                    <label class="lead" for="">Estado: <?php echo e($address->estado); ?></label><br>
                                    <label class="lead" for="">Colonia: <?php echo e($address->colonia); ?></label><br>
                                    <label class="lead" for="">Código postal: <?php echo e($address->cp); ?></label><br>
                                    <?php if(trim($address->calle2)): ?> 
                                        <label class="lead" for="">Segunda callle: <?php echo e($address->calle2); ?></label><br>
                                    <?php else: ?> 
                                        <label class="lead" for="">Segunda callle: Sin segunda calle</label><br>
                                    <?php endif; ?>
                                    <?php if(trim($address->calle3)): ?> 
                                        <label class="lead" for="">Tercera callle: <?php echo e($address->calle3); ?></label><br>
                                    <?php else: ?> 
                                        <label class="lead" for="">Tercera callle: Sin tercera calle</label><br>
                                    <?php endif; ?>
                                    <?php if(trim($address->numInterior)): ?> 
                                        <label class="lead" for="">Número interior: <?php echo e($address->numInterior); ?></label><br>
                                    <?php else: ?> 
                                        <label class="lead" for="">Número interior: Sin número interior</label><br>
                                    <?php endif; ?>
                                    <?php if(trim($address->numExterior)): ?> 
                                        <label class="lead" for="">Número exterior: <?php echo e($address->numExterior); ?></label><br>
                                    <?php else: ?> 
                                        <label class="lead" for="">Número exterior: Sin número exterior</label><br>
                                    <?php endif; ?>
                                    <?php if(trim($address->numExterior)): ?> 
                                        <label class="lead" for="">Referecias: <?php echo e($address->referencias); ?></label>
                                    <?php else: ?> 
                                        <label class="lead" for="">Referecias: Sin referencias</label><br>
                                    <?php endif; ?>

                                </div>
                                <!-- <div class="form-inline" style="margin-left: 95%;">
                                    <button class="btn btn-danger btn-xs btn-delete" data-toggle="tooltip" value="<?php echo e($address->id); ?>" data-placement="top" title="Eliminar"><i class="fa fa-minus-square" aria-hidden="true"></i></button>
                                </div>  -->
                            </div>
                        </div>
                        <?php
                            $id++;
                        ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




            </div>
        <!-- </form> -->
    <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('mostrar-modal'); ?>
    <?php if($errors->any()): ?>
        <script>
            $(function() {
                $('#add_address').modal('show');
            });
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>

    // $(document).ready(function() {
    //     var direccionActiva = $('input[name="choices[1]"]:checked').val();
    //     $('.activo').click(function(){
    //         direccionActiva = $('input[name="choices[1]"]:checked').val();
    //         console.log(direccionActiva);
    //         console.log('hola');
    //     });
    //     console.log(direccionActiva);
    //     alert(direccionActiva);
    // });
    // $(document).ready(function(){

        

    //     $('.btn-click').click(function(){

    //     var label = $(this).parents('label');


            
    //         while($('.btn-validate').length){
    //             $('.btn-validate').removeClass('btn-success');
    //             $('.btn-validate').addClass('btn-warning');
    //             $('.icon-validate').removeClass('glyphicon-ok');
    //             $('.icon-validate').addClass('glyphicon-remove');
    //             $('.icon-validate').addClass('icon-click');
    //             $('.icon-validate').removeClass('icon-validate');
    //             $('.btn-validate').addClass('btn-click');
    //             $('.btn-validate').removeClass('btn-validate');

    //         }

    //         label.removeClass('glyphicon-remove');
    //         label.addClass('glyphicon-ok');
    //         label.removeClass('btn-warning');
    //         label.addClass('btn-success');
    //         label.addClass('btn-validate');
    //         label.removeClass('btn-click');

    // });
    // });
    
</script> 
<?php $__env->stopPush(); ?>

<?php echo $__env->make('customer.dash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>