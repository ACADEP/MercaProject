<!DOCTYPE html>
<html lang="es">
  <head>
    <meta charset="utf-8">
    <title>Recibo de Pago</title>
    <link href="<?php echo e(asset('/css/app.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('/css/InvoicePayment.css')); ?>" media="all" />
  </head>
  <body>
    <?php  $now = new \DateTime(); ?>
    <header class="clearfix">
      <div id="logo">
          <div class="mercaLogo">
            <img src="<?php echo e(asset(config('configurations.general.main_logo'))); ?>">
          </div>
            <div class="slogan font">
                <strong><h3 class="font"><?php echo e(config('configurations.general.store_name')); ?></h3></strong>
                <?php echo e(config('configurations.mk.slogan')); ?> 
            </div>
      </div>
      <h1 class="tittle font">Recibo de Pago</h1>
      
      <div class="row" id="dates">
        <div class="col-sm-6 col-md-6" id="project">
          <div><span><strong>Cliente</strong></span> <?php echo e(Auth::User()->customer->nombre); ?></div>
          <div><span><strong>Dirección</strong></span> <?php echo e(Auth::user()->addressActive()->calle); ?>, <?php echo e(Auth::user()->addressActive()->ciudad); ?> <?php echo e(Auth::user()->addressActive()->cp); ?>, <?php echo e(Auth::user()->addressActive()->estado); ?></div>
          <div><span><strong>Correo</strong></span> <a href="mailto:<?php echo e(Auth::User()->email); ?>"><?php echo e(Auth::User()->email); ?></a></div>
          <div><span><strong>Fecha</strong></span> <?php echo e($now->format('d-m-Y')); ?></div>
          <div><span><strong>Expiración</strong></span> <?php echo e(Carbon\Carbon::now()->addDay(1)); ?></div>
        </div>
    
        <div class="col-sm-6 col-md-6 text-right" id="company" class="clearfix font">
        <div><strong><?php echo e(config('configurations.general.store_name')); ?></strong></div>
          <div><?php echo e(config('configurations.company.direction_1')); ?>,<br /> 
                <?php echo e(config('configurations.company.city')); ?> <?php echo e(config('configurations.company.postal_code')); ?>, 
                <?php echo e(config('configurations.company.country_code')); ?></div>
          <div>Tel:  <?php echo e(config('configurations.company.phone')); ?></div>
          <div><a href="mailto:mercadata@acadep.com">mercadata@acadep.com</a></div>
        </div>  
      </div>
    </header>

    <main>
      <table>
        <thead>
          <tr>
            <th class="service"><strong>Cantidad</strong></th>
            <th class="desc"><strong>Código</strong></th>
            <th><strong>Descripción</strong></th>
            <th><strong>Precio</strong></th>
            <th><strong>Total</strong></th>
          </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $itemsCart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="service"><?php echo e($item->qty); ?></td>
                <td class="desc"><?php echo e($item->product->product_sku); ?></td>
                <td class="unit"><?php echo e($item->product->description); ?></td>
                <td class="qty">$<?php echo e(number_format($item->product_price, 2)); ?></td>
                <td class="total">$<?php echo e(number_format($item->total, 2)); ?></td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td colspan="4">Subtotal</td>
            <td class="total">$<?php echo e(number_format( Auth::user()->total, 2)); ?></td>
          </tr>
          <tr>
            <td colspan="4">IVA</td>
            <td class="total">Incluido</td>
          </tr>
          <tr>
            <td colspan="4">Costo de envío</td>
            <td class="total"><?php echo e($ship_rate); ?></td>
          </tr>    
          <tr>
            <td colspan="4" class="grand total">Total</td>
            <td class="grand total">$<?php echo e(number_format( $ship_rate_total, 2)); ?></td>
          </tr>
        </tbody>
      </table>
      <div id="notices">
        <div><strong>Forma de pago: </strong>Banco</div>
        <div><strong>Tiempo de Entrega: </strong><?php echo e($date_ship); ?></div>
        <div><strong><?php echo e(config('configurations.mk.greetings')); ?></strong></div>
        <div class="notice"><?php echo e(config('configurations.mk.information_final_2')); ?></div>
        <div class="notice"><?php echo e(config('configurations.mk.information_final')); ?></div>
      </div>

      <br>
      <h2 class="tittle font">Pasos para realizar el pago</h2>
      <div class="row" id="pago">
        <div class="col-sm-6 col-md-6" id="bancomer">
          <div><h4>Desde BBVA Bancomer</h4></div>
          <div><span>1. El cliente deberá ingresar a su banca en linea y </span></div>
          <div><span>dentro del menú "Pagar" seleccionar "De servicios".</span></div>
          <div><span>2. <strong>Número de convenio CIE: </strong><?php echo e($charge->payment_method->agreement); ?></span></div>
          <div><span>3. Ingrese los datos de registro para concluir con la</span></div>
          <div><span>operación.</span></div>
          <div><span><strong>Referencia: </strong><?php echo e($charge->order_id); ?></span></div>
          <div><span><strong>Importe: </strong>$<?php echo e($charge->amount); ?> MXN</span></div>  
          <div><span><strong>Concepto: </strong><?php echo e($charge->customer->name.' '.$charge->customer->last_name); ?></span></div>
        </div>
    
        <div class="col-sm-6 col-md-6" id="otros">
            <div><h4>Desde cualquier otro banco</h4></div>
            <div><span>1. Ingresar a la sección de transferencias o pagos a terceros y</span></div>
            <div><span>proporcionar los datos de la transferencia, monto y concepto del pago.</span></div>
            <div><span><strong>Beneficiario: </strong>Mercadata</span></div>
            <div><span><strong>Banco destino: </strong><?php echo e($charge->payment_method->bank); ?></span></div>
            <div><span><strong>Clabe: </strong><?php echo e($charge->payment_method->clabe); ?></span></div>
            <div><span><strong>Concepto de pago: </strong><?php echo e($charge->customer->name.' '.$charge->customer->last_name); ?></span></div>
            <div><span><strong>Referencia: </strong><?php echo e($charge->order_id); ?></span></div>
            <div><span><strong>Importe: </strong>$<?php echo e($charge->amount); ?> MXN</span></div>  
        </div>  
      </div>
    </main>
    <footer>
        <div class="row data">
            <div class="address">
                <span>Dirección: </span>
                <strong><?php echo e(config('configurations.company.city')); ?> <?php echo e(config('configurations.company.postal_code')); ?>, 
                <?php echo e(config('configurations.company.country_code')); ?></strong>
            </div>
            <div class="phone">
                <span>Teléfono: </span>
                <strong> <?php echo e(config('configurations.company.phone')); ?></strong>
            </div>
        </div>
    </footer>
  </body>
</html>