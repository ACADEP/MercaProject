<?php if(isset($search)): ?>
<table class="table text-center" style="width:100%;"> 
<thead>
    <tr>
        <th></th>
        <th>Código</th>
        <th>Nombre</th>
        <th>Precio</th>
        <th>Cantidad</th>
        <th></th>
    </tr>
</thead>
<tbody>
    <?php $__currentLoopData = $search; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr id="product<?php echo e($product->id); ?>">
        <input type="hidden" id="product_photo<?php echo e($product->id); ?>" value="<?php echo e($product->photos()->first() ? $product->photos()->first()->path : '/images/no-image-found.jpg'); ?>">
            <td class="col-md-1"><img src="<?php echo e($product->photos()->first() ? $product->photos()->first()->path : '/images/no-image-found.jpg'); ?>" style="width:50%;"></td>
            <td >
                <input type="text" class="form-control" id="product_sku<?php echo e($product->id); ?>" style="width:100%;" value="<?php echo e($product->product_sku); ?>">
            </td>

            <td >
                <input type="text" class="form-control" id="product_name<?php echo e($product->id); ?>" style="width:100%;"  value="<?php echo e($product->product_name); ?>">
            </td>

            <td class="form-inline "><input type="text" class="form-control product_price" style="width:100%;" id="product_price<?php echo e($product->id); ?>" value="<?php echo e($product->mr_price); ?>"></td>
            <td >
                <input type="number" class="form-control" id="qty_product<?php echo e($product->id); ?>" style="width:100%;" min="1" value="1">
                
                </select>
            </td>
            <td > 
                
                    <button class="btn btn-primary btn-sm btn-add-market" style="width:100%;" data-toggle="tooltip" title="Agregar" value="<?php echo e($product->id); ?>">
                        <i class="fa fa-plus"></i>
                    </button>
                
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>

</table>

<div class="text-center">
<?php echo e($search->appends(request()->except('page'))->links()); ?>


</div>
<?php endif; ?>

<?php $__env->startPush('scripts'); ?>
    <script>
         $(".product_price").keydown(function(event) {
        // Allow only backspace and delete
        if ( event.keyCode == 46 || event.keyCode == 8 ) {
            // let it happen, don't do anything
        }
        else {
            // Ensure that it is a number and stop the keypress
            if (event.keyCode < 48 || event.keyCode > 57 ) {
                event.preventDefault(); 
            }   
        }
    });
    </script>
<?php $__env->stopPush(); ?>