
  
  <nav class="navbar navbar-light navbar-expand-lg bg-light sticky-top" id="navbar-header">
    
    
    <a class="navbar-brand" href="<?php echo e(url('/')); ?>" id="nav-bar-logo"><img src="/images/logo-home.png" style="float: left; width: 240px; height:80;"></a>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
          </button>
          
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
              <ul class="navbar-nav mr-auto">
                
              <div class="nav-menu">

                    <li class="nav-item">
                        <?php echo $__env->make('pages.partials.search_box', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    
                       
                    </li>
                <?php $categories=App\Category::where('parent_id',0)->take(5)->get(); ?>
                <div id="search_down">
                    <li class="nav-item dropdown" >
                            
                            <a class="nav-link dropdown-toggle hidden-md-down" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Categorías </a>
                                
                                <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                    <!-- Categorias y subcategorias -->
                                
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($category->totalSubcategories() >0): ?>
                                        <li class="dropdown-submenu"><a class="dropdown-item dropdown-toggle" href="#"><?php echo e($category->category); ?></a>
                                            <ul class="dropdown-menu">
                                            <?php $__currentLoopData = $category->children()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><a class="dropdown-item" href="#"><?php echo e($sub->category); ?></a></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </li>
                                        <?php else: ?>
                                        <li><a class="dropdown-item" href="#"><?php echo e($category->category); ?></a></li>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   
                                    <li><a class="dropdown-item" style="color:blue;" href="<?php echo e(route('categories.all')); ?>">Ver mas categorias</a></li>
                                </ul>
                        </li>
                    </div>
                        
                </div>
                &nbsp&nbsp&nbsp
                <div class="nav-menu">
                    <div id="form-search-down">
                        <li class="nav-item">
                            <div id="form-sesion">
                                <?php if(Auth::check()): ?>
                                    <div class="form-inline">
                                        <?php if(Auth::user()->admin==2): ?>
                                            <a href="<?php echo e(url('/seller/admin')); ?>">Mi Perfil</a>&nbsp | &nbsp
                                        <?php else: ?>
                                        <?php if(Auth::user()->admin==1): ?>
                                            <a href="<?php echo e(url('/admin/index')); ?>">Mi Perfil</a>&nbsp | &nbsp
                                        <?php else: ?>
                                            <a href="<?php echo e(url('/customer/profile')); ?>">Mi Perfil</a>&nbsp | &nbsp
                                        <?php endif; ?>
                                        <?php endif; ?>
                                        <a href="<?php echo e(url('/logout')); ?>">Salir</a>
                                    </div>
                                    
                                <?php else: ?>  
                                    <a href="<?php echo e(url('/login')); ?>">Inicio de sesión </a>&nbsp &nbsp
                                    <a href="<?php echo e(url('/register')); ?>">Registrarse</a>&nbsp&nbsp
                                <?php endif; ?>
                                <!-- <a href="#" id="cart"><i class="material-icons"> shopping_cart</i><span class="badge">3</span></a> -->
                                
                            </div>
                        </li>
                    <?php echo $__env->make('partials.shopping-cart-container', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    <br><br>
                        <li class="nav-item">
                            <a data-toggle="modal"  data-target="#exampleModalCenter">Búsqueda especial</a>
                        </li>
                        &nbsp&nbsp
                        <li class="nav-item">
                            <a href="#">Nosotros</a>
                        </li>
                        &nbsp&nbsp
                        <li class="nav-item">
                            <a href="#">Ayuda</a>
                        </li>
                    </div>
                    
                </div>  

            </ul>

              </div>
    </nav>
    

<!-- Estilos de la plantilla -->
  <?php $__env->startSection('styles'); ?>
  <style>
      #form-search-down li{
           display: inline-block;
       }
       #form-search-down a{
           text-decoration:none;
       }
       #search_down{
           width: 18%;
       }
       
       .badge {
            background-color: #6394F8;
            border-radius: 10px;
            color: white;
            display: inline-block;
            font-size: 10px;
            line-height: 1;
            padding: 2px 7px;
            text-align: center;
            vertical-align: middle;
            white-space: nowrap;
        }

       
       
  </style>
 

  <?php $__env->stopSection(); ?>

  

