<?php $__env->startSection('content'); ?>

    <nav aria-label="breadcrumb" class="pt-3">
        <ol class="breadcrumb breadcrumb-right-arrow">
            <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Inicio</a></li>
            <li class="breadcrumb-item"><a href="<?php echo e(url('/brands')); ?>">Marcas</a></li>
            <li class="breadcrumb-item active" aria-current="page"><?php echo e($brand->brand_name); ?></li>
        </ol>
    </nav>    

    <div class="row">
        <div class="row col-sm-3 col-md-3">
            <?php echo $__env->make('pages.filter',["route"=>route('bran.filter', $brand->id)], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>

        <div class="row col-sm-9 col-md-9 text-center ml-4">
            <?php echo $__env->make('pages.utils.product-card', ["data"=>$products], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>

    <div class="row justify-content-center mt-3 pl-5">
        <?php echo e($products->appends(Request::input())->links()); ?>

    </div>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>