<?php $__env->startSection('content'); ?>

            <h3 class="text-center">
                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($brand->brand_name); ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </h3>

            <div class="dropdown">
                <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">Ordenar por
                    <span class="caret"></span></button>
                <ul class="dropdown-menu">
                    <li><a href="<?php echo e(route('brand.newest', $brand->id)); ?>">Mas nuevos</a></li>
                    <li><a href="<?php echo e(route('brand.lowest', $brand->id)); ?>">Precio mas bajo</a></li>
                    <li><a href="<?php echo e(route('brand.highest', $brand->id)); ?>">Precio mas alto</a></li>
                    <li><a href="<?php echo e(route('brand.alpha.lowest', $brand->id)); ?>">Productos A-Z</a></li>
                    <li><a href="<?php echo e(route('brand.alpha.highest', $brand->id)); ?>">Productos Z-A</a></li>
                </ul>
            </div>



            <br>
            <p><?php echo e($count); ?> <?php echo e(str_plural('product', $count)); ?></p>

            <div class="row">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-12 wow slideInLeft" id="product-sub-container">
                        <div class="col-md-4 text-center hoverable">
                            <a href="<?php echo e(route('show.product', $product->product_name)); ?>">
                            <?php if($product->photos->count() === 0): ?>
                                    <img src="<?php echo e(asset('/images/no-image-found.jpg')); ?>" alt="No Image Found Tag" id="Product-similar-Image">
                            <?php else: ?>
                                <?php if($product->featuredPhoto): ?>
                                    <img src="<?php echo e(asset($product->featuredPhoto->thumbnail_path)); ?>" alt="Photo ID: <?php echo e($product->featuredPhoto->id); ?>" width="50%" />
                                <?php elseif(!$product->featuredPhoto): ?>
                                    <img src="<?php echo e(asset($product->photos->first()->thumbnail_path)); ?>" alt="Photo" />
                                <?php else: ?>
                                    N/A
                                <?php endif; ?>
                            <?php endif; ?>
                            </a>
                        </div>
                        <div class="col-md-5">
                            <a href="<?php echo e(route('show.product', $product->product_name)); ?>">
                            <h5 class="center-on-small-only"><?php echo e($product->product_name); ?></h5>
                            <h6 class="center-on-small-only">Brand: <?php echo e($product->brand->brand_name); ?></h6>
                            <p style="font-size: .9em;"><?php echo nl2br(str_limit($product->description, $limit = 200, $end = '...')); ?></p>
                            </a>
                        </div>
                        <div class="col-md-3 text-center">
                            <?php if($product->reduced_price == 0): ?>
                                $ <?php echo e($product->price); ?>

                                <br>
                            <?php else: ?>
                                <div class="text-danger list-price"><s>$ <?php echo e($product->price); ?></s></div>
                                $ <?php echo e($product->reduced_price); ?>

                            <?php endif; ?>
                            <br><br><br>
                                <form action="/store/cart/add" method="post" name="add_to_cart">
                                    <?php echo csrf_field(); ?>

                                    <input type="hidden" name="product" value="<?php echo e($product->id); ?>" />
                                    <input type="hidden" name="qty" value="1" />
                                    <button class="btn btn-default waves-effect waves-light">Agregar al carrito</button>
                                </form>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>


       

    

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>