<?php $__env->startSection('content'); ?>
<div class="col-md-12" id="body-cart">
<div id="loader-contener"></div>
<div class="row col-md-12">
    <?php if(Auth::check()==false): ?>
        <div class="alert alert-primary lert-dismissible fade show mt-3" role="alert">
            Inicie sesión o Regístrese para completar su compra.
            <button type="button" class="close ml-3" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>
    <div class="text-center col-12 col-sm-12 col-md-12 pt-2">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb breadcrumb-right-arrow">
                <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Inicio</a></li>
                <li class="breadcrumb-item active" aria-current="page">Carrito</li>
            </ol>
        </nav>  
    </div>
    <form class="form-inline text-right"  method="get" action="<?php echo e(route('cart.pdf')); ?>">
        <div class="text-right" style="width:100%;">
            <input type="hidden" name="Items" id="items-carts">
            <button class="btn btn-primary btn-just-icon" formtarget="_blank" type="submit">
                    <i class="material-icons">local_printshop</i>
            </button>
            <?php if(Auth::check()): ?>
                <?php if(Auth::user()->carts()->count()>0): ?>
                    <div id="btn-pay-div" style="display:inline;"> <a href="<?php echo e(route('pay-cart')); ?>" class="btn btn-success text-center " id="btn-pay-cart">Pagar</a></div>  
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </form>            
</div>
        

<table class="table text-center">
        <thead>
            <tr>
                <th></th>
                <th>Nombre</th>
                <th>Precio</th>
                <th>Cantidad</th>
                <th>SubTotal</th>
                <th>Eliminar</th>
            </tr>
        </thead>

        <tbody <?php echo e(Auth::check() ? 'id=client-body' : 'id=tbody'); ?>>
        
           <?php if(Auth::check()): ?>
                
                <?php $__currentLoopData = Auth::user()->cart->with("product")->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <tr id="item-cart<?php echo e($cart->id); ?>">
                       
                       <td style="width:100px;"><img style="width:100%;" src="<?php echo e($cart->product->photos()->first()->path); ?>" alt=""></td>
                        <td> <a href="<?php echo e(route('show.product', $cart->product->id)); ?>"><?php echo e($cart->product->product_name); ?></a></td>
                        
                        <td>$<?php echo e(number_format(($cart->product_price), 2)); ?></td>
                        <td>
                            <select class="form-control selectCtd" id="<?php echo e($cart->id); ?>">
                                <?php for($i = 0; $i < $cart->product->product_qty; $i++): ?>
                                    <option value="<?php echo e($i+1); ?>"><?php echo e($i+1); ?></option>
                                <?php endfor; ?>
                            </select>
                        </td>
                        <script>document.getElementById("<?php echo e($cart->id); ?>").value = "<?php echo e($cart->qty); ?>";</script>
                        <td id="total-client<?php echo e($cart->id); ?>">$<?php echo e(number_format($cart->total, 2)); ?> 
                       
                        </td>
                        <input type="hidden" id="url" value="/cart/delete">
                        <td><button type='button' value="<?php echo e($cart->id); ?>" class='btn btn-outline-danger btn-sm cart-delete'><i class="fa fa-trash" aria-hidden="true"></i></button></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
           <?php endif; ?>
          
           
        </tbody>
        
    </table>
    <?php if(Auth::check()): ?>
       <div class="col-md-12 text-center" id="alert-cartP-A" style="font-size:25px;<?php echo e(Auth::user()->cart->count()==0 ? 'height:250px': ''); ?>"> <?php if(Auth::user()->cart->count()==0): ?> No hay productos en este carrito <?php endif; ?></div>
  
    <?php else: ?>
        <div class="col-md-12 text-center" id="alert-cartP" style="font-size:25px;"></div>
    <?php endif; ?>
    
<div class="text-right" <?php echo e(Auth::check() ? 'id=client-total' : 'id=general-total'); ?>>
    <?php if(Auth::check()): ?>
        El total de su carrito es: $<?php echo e(number_format(Auth::user()->total, 2)); ?>

    <?php endif; ?>
</div>
                             
</div>
<style>
    #loader {
        position: fixed;
        left: 0px;
        top: 0px;
        width: 100%;
        height: 100%;
        z-index: 9999;
        background: url('images/pageLoader.gif') 50% 50% no-repeat rgb(249,249,249);
        opacity: .8;
    }
</style>
<script>

    $("#btn-pay-cart").click(function(){
        $("#loader-contener").html("<div id='loader' class='text-center' style='font-size:40px; '><span style='padding-top:300px;'>Espere por favor</span> </div>");
    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>