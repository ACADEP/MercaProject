<?php $__env->startSection('content'); ?>
<div class="col-md-12" style="height:100%; widht=100%;">
    <table class="table">
        <thead>
            <tr>
                <th>Nombre</th>
                <th>Precio</th>
                <th>Cantidad</th>
                <th>SubTotal</th>
                <th>Opciones</th>
            </tr>
        </thead>

        <tbody <?php echo e(Auth::check() ? 'id=client-body' : 'id=tbody'); ?>>
        
           <?php if(Auth::check()): ?>
                
                <?php $__currentLoopData = Auth::user()->carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <tr id="item-cart<?php echo e($cart->id); ?>">
                        <td><?php echo e(Auth::user()->product($cart->product_id)->product_name); ?></td>
                        <td><?php echo e(Auth::user()->product($cart->product_id)->price); ?></td>
                        <td>
                            <select class="form-control selectCtd" id="<?php echo e($cart->id); ?>">
                                <?php for($i = 0; $i < Auth::user()->product($cart->product_id)->product_qty; $i++): ?>
                                    <option value="<?php echo e($i+1); ?>"><?php echo e($i+1); ?></option>
                                <?php endfor; ?>
                            </select>
                        </td>
                        <td id="total-client<?php echo e($cart->id); ?>"><?php echo e($cart->total); ?></td>
                        <input type="hidden" id="url" value="<?php echo e(route('deleteCart')); ?>">
                        <td><button type='button' value="<?php echo e($cart->id); ?>" class='btn btn-outline-danger btn-sm cart-delete'>Borrar</button></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           <?php endif; ?>
          
           
        </tbody>
        
    </table>
    <form class="form-inline" method="get" action="<?php echo e(route('cart.pdf')); ?>">
        <input type="hidden" name="Items" id="items-carts">
            <button class="btn btn-primary btn-just-icon" type="submit">
                    <i class="material-icons">local_printshop</i> Imprimir PDF
            </button>
    </form>
    
    <?php if(Auth::check()): ?>
        <button type="button" class="btn btn-success text-center"><i class="material-icons">attach_money</i> Pagar</button>
    <?php endif; ?>
        
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>