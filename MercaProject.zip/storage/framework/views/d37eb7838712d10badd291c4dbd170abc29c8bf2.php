<?php $__env->startSection('content'); ?>
<div class="col-md-12" id="body-cart">

<div class="row col-md-12">
    <?php if(Auth::check()==false): ?>
        <div class="alert alert-primary" role="alert">
            Inicie sesión o Regístrese para completar su compra.
        </div>
    <?php endif; ?>
    <div class="text-center col-10 col-sm-10 col-md-10 pt-2">
        <nav aria-label="breadcrumb" style="width: 20%;">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Inicio</a></li>
                <li class="breadcrumb-item"><a href="">Carrito</a></li>
            </ol>
        </nav>  
    </div>
    <form class="form-inline text-right"  method="get" action="<?php echo e(route('cart.pdf')); ?>">
        <div class="text-right" style="width:100%;">
            <input type="hidden" name="Items" id="items-carts">
            <button class="btn btn-primary btn-just-icon" formtarget="_blank" type="submit">
                    <i class="material-icons">local_printshop</i>
            </button>
            <?php if(Auth::check()): ?>
                <?php if(Auth::user()->carts()->count()>0): ?>
                    <div id="btn-pay-div" style="display:inline;"> <a href="<?php echo e(route('pay-cart')); ?>" class="btn btn-success text-center">Pagar</a></div>  
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </form>
</div>
        

<table class="table text-center">
        <thead>
            <tr>
                <th>Nombre</th>
                <th>Precio</th>
                <th>Cantidad</th>
                <th>SubTotal</th>
                <th>Eliminar</th>
            </tr>
        </thead>

        <tbody <?php echo e(Auth::check() ? 'id=client-body' : 'id=tbody'); ?>>
        
           <?php if(Auth::check()): ?>
                <?php $__currentLoopData = Auth::user()->cart->with("product")->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <tr id="item-cart<?php echo e($cart->id); ?>">
                       
                        <td> <a href="<?php echo e(route('show.product', $cart->product->product_name)); ?>"><?php echo e($cart->product->product_name); ?></a></td>
                    
                        <td>$<?php echo e(number_format(($cart->product_price), 2)); ?></td>
                        <td>
                            <select class="form-control selectCtd" id="<?php echo e($cart->id); ?>">
                                <?php for($i = 0; $i < $cart->product->product_qty; $i++): ?>
                                    <option value="<?php echo e($i+1); ?>"><?php echo e($i+1); ?></option>
                                <?php endfor; ?>
                            </select>
                        </td>
                        <script>document.getElementById("<?php echo e($cart->id); ?>").value = "<?php echo e($cart->qty); ?>";</script>
                        <td id="total-client<?php echo e($cart->id); ?>">$<?php echo e(number_format($cart->total, 2)); ?> 
                       
                        </td>
                        <input type="hidden" id="url" value="/cart/delete">
                        <td><button type='button' value="<?php echo e($cart->id); ?>" class='btn btn-outline-danger btn-sm cart-delete'><i class="fa fa-trash" aria-hidden="true"></i></button></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           <?php endif; ?>
          
           
        </tbody>
        
    </table>
<div class="text-right" <?php echo e(Auth::check() ? 'id=client-total' : 'id=general-total'); ?>>
    <?php if(Auth::check()): ?>
        El total de su carrito es: $<?php echo e(number_format(Auth::user()->total, 2)); ?>

    <?php endif; ?>
</div>
                        
   
    
    
   
        
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>