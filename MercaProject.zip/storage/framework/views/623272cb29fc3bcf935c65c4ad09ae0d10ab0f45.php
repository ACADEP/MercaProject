<!DOCTYPE html>
<html lang="en">
    <head>

        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
       
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <meta name=description content="A medium sized e-commerce shopping cart made by David Trushkov. Made using Laravel 5.2" />
        <meta name="keywords" content="shopping, ecommerce, store, electronics, electronics store, david, david trushkov, github, laravel, laravel 5, laravel 5.2" />
        <meta name="author" content="David Trushkov" />
        <link rel="shortcut icon" href="<?php echo asset('/images/logo-mercadata.png'); ?>" />

        <title><?php echo e(config('app.name')); ?></title>
        <!-- Font Awesome -->
        <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"> -->
        <!-- Bootstrap core CSS -->
        <!-- <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet"> -->
        <!-- Material Design Bootstrap -->
        <link href="<?php echo e(asset('css/mdb.min.css')); ?>" rel="stylesheet">
        <!-- Your custom styles (optional) -->
        <!-- <link href="css/style.css" rel="stylesheet"> -->
        <!-- <link rel="stylesheet" href="<?php echo e(asset('/css/bootstrap.min.css')); ?>"> -->

        <!-- <link rel="stylesheet" href="<?php echo e(asset('/css/mdb.css')); ?>"> -->

        <!-- Payments css -->
        <link rel="stylesheet" href="<?php echo e(asset('/css/payments.css')); ?>">
       
        <!-- Include sweet alert file -->
        <!-- <link rel="stylesheet" href="<?php echo e(asset('/css/sweetalert.css')); ?>"> -->
        <!-- Include typeahead file -->
        <!-- <link rel="stylesheet" href="<?php echo e(asset('/css/typeahead.css')); ?>"> -->
        <!-- Include lity ligh-tbox file -->
        <!-- <link rel="stylesheet" href="<?php echo e(asset('/css/lity.css')); ?>"> -->
      
       <?php echo $__env->yieldContent('css-openpay'); ?>

        <!-- Added the main.css file that combines app.scss and app.css togather -->
        




        <!-- Scripts -->
        <script src="<?php echo e(asset('/js/app.js')); ?>" ></script>
        
        <link href="<?php echo e(asset('/css/app.css')); ?>" rel="stylesheet">

         <link rel="stylesheet" type="text/css" href="/css/payments.css" data-rel-css="" />
        
        <script src="<?php echo e(asset('/js/bootstrap-notify.min.js')); ?>"></script>
        <!-- <link rel="stylesheet" href="<?php echo e(asset('/less/app.less')); ?>">

        <link rel="stylesheet" href="<?php echo e(asset('/sass/app.scss')); ?>"> -->
        
        <link rel="stylesheet" href="<?php echo e(asset('/css/style.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('/css/main.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('/css/pay.css')); ?>" >
        <script type="text/javascript" src="<?php echo e(asset('/js/js.cookie.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(asset('/js/Main.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(asset('/js/ajax.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(asset('/js/ajax-client.js')); ?>"></script>
        <script type="text/javascript" src="<?php echo e(asset('/js/ajax-products.js')); ?>"></script>
        <?php echo $__env->yieldContent("ajax-shipment"); ?>
        <script>
            function borrarCache()
            {
                Cookies.remove("productos");
            }
        </script>   

        <!-- Openpay -->
        <script type="text/javascript" src="https://openpay.s3.amazonaws.com/openpay.v1.min.js"></script>
        <script type='text/javascript' src="https://openpay.s3.amazonaws.com/openpay-data.v1.min.js"></script>
        <script type="text/javascript">
            $(document).ready(function() {
                   OpenPay.setId('mk5lculzgzebbpxpam6x');
                   OpenPay.setApiKey('pk_26757cbb5f7f44e8b31a2aed751c285c');
                   OpenPay.setSandboxMode(true);
           });
       </script>

        <!-- Material Design Icons -->
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Lato:100" rel="stylesheet" type="text/css">
        <!-- Font Awesome -->
        <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css" rel="stylesheet" >
     
        <script>
            // (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
            //             (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
            //         m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
            // })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
            // ga('create', 'UA-76800406-1', 'auto');
            // ga('send', 'pageview');
        </script>

    </head>
<body>
            
    <?php echo $__env->make('partials.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            
   
    <div class="container">
    <?php if(Session::has('pay-success') || Session::has('progress')): ?>
        <?php Session::forget('progress');  ?>
        <script> 
            var notify = $.notify('<div style="font-size:25px;"><h3>Compra existosa!!</h3>Revise su correo electrónico o su historial de compras para descargar su recibo</div>', { allow_dismiss: false });
        </script>
    <?php endif; ?>
        <?php echo $__env->yieldContent('content'); ?>
          
    </div>
                
            
     <?php echo $__env->make('pages.partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    
    <!-- Include sweet-alert.js file -->
    <!-- <script type="text/javascript" src="<?php echo e(asset('/js/libs/sweetalert.js')); ?>"></script> -->
    <!-- Include typeahead.js file -->
    <!-- <script type="application/javascript" src="<?php echo e(asset('/js/libs/typeahead.js')); ?>"></script> -->
    <!-- Include lity light-box js file -->
    <!-- <script type="application/javascript" src="<?php echo e(asset('/js/libs/lity.js')); ?>"></script> -->

 
    
   
   
    

   
<style>
.team .row .col-md-4 {
    margin-bottom: 5em;
}
.team .row {
  display: -webkit-box;
  display: -webkit-flex;
  display: -ms-flexbox;
  display:         flex;
  flex-wrap: wrap;
}
.team .row > [class*='col-'] {
  display: flex;
  flex-direction: column;
}

.tt-query {
  -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
     -moz-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
          box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075);
}

.tt-hint {
  color: #999
}

.tt-menu {    /* used to be tt-dropdown-menu in older versions */
  width: 99%;
  margin-top: 4px;
  padding: 4px 0;
  background-color: #fff;
  border: 1px solid #ccc;
  border: 1px solid rgba(0, 0, 0, 0.2);
  -webkit-border-radius: 4px;
     -moz-border-radius: 4px;
          border-radius: 4px;
  -webkit-box-shadow: 0 5px 10px rgba(0,0,0,.2);
     -moz-box-shadow: 0 5px 10px rgba(0,0,0,.2);
          box-shadow: 0 5px 10px rgba(0,0,0,.2);
}

.tt-suggestion {
  padding: 3px 20px;
  line-height: 24px;
}

.tt-suggestion.tt-cursor,.tt-suggestion:hover {
  color: #fff;
  background-color: #0097cf;

}

.tt-suggestion p {
  margin: 0;
}

.grow img
{
    transition: 1s ease;
}
    
.grow img:hover
{
    -webkit-transform: scale(1.2);
    -ms-transform: scale(1.2);
    transform: scale(1.2);
    transition: 1s ease;
}


        
</style>
   
    <script src="<?php echo e(asset('/js/typeahead.bundle.min.js')); ?>"></script>
    <script>
           
   
            $(function () {
            
            var datos = new Bloodhound({
                
              datumTokenizer: Bloodhound.tokenizers.whitespace,
              queryTokenizer: Bloodhound.tokenizers.whitespace,
            
             prefetch: {
                url: '/getData',
                ttl:0,
                cache: false,
            }
             
            }); 
            
            // inicializar typeahead sobre nuestro input de búsqueda
            $('#search').typeahead({
                hint: true,
                highlight: true,
                minLength: 1
            }, {
                name: 'datos',
                source: datos
            });
            
        });
    </script>
   
    <?php echo $__env->yieldContent('modal-debit'); ?>
   
   
    <?php echo $__env->yieldContent('styles'); ?>
    <?php echo $__env->yieldContent('js'); ?>
    <?php echo $__env->yieldContent('css-pay'); ?>
    <?php echo $__env->yieldContent('js-pay'); ?>
    <?php echo $__env->yieldContent('show-modal'); ?>
    <?php echo $__env->yieldContent('modal-transfer'); ?>
    <?php echo $__env->yieldContent('scripts-progress'); ?>
    <?php echo $__env->make('partials.flash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('partials.special_search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->make('customer.partials.add-address', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo $__env->yieldContent('modal-paypal'); ?>

</body>
</html>
