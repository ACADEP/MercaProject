<?php $__env->startSection('content'); ?>
<section class="content-header">
        <h1>
           Mis productos favoritos
        </h1>
</section><br>
<?php if($favorites->count() > 0): ?>
<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
<?php $i=1;?>
<div class="panel panel-default">
<?php $__currentLoopData = $favorites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $favorite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   
    <div class="panel-heading" role="tab" id="heading<?php echo e($i); ?>" style="background-color:rgb(204, 204, 204); border: solid 1px;">
      <h4 class="panel-title">
        <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse<?php echo e($i); ?>" aria-expanded="true" aria-controls="collapse<?php echo e($i); ?>">
          <span class="label label-primary" style="font-size:15px;"><?php echo e($favorite->product->product_name); ?></span> 
        </a>
      </h4>
    </div>
    <div id="collapse<?php echo e($i); ?>" class="<?php echo e($i==1 ? 'panel-collapse collapse in' : 'panel-collapse collapse'); ?>" role="tabpanel" aria-labelledby="heading<?php echo e($i); ?>">
      <div class="panel-body">
        <div class="text-left" >
           
        </div>
        <div class="text-right">
        <form action="<?php echo e(route('delete-favorite')); ?>" method="post" style="display:inline;">
            <?php echo e(csrf_field()); ?>

            <input type="hidden" name="favorite" value="<?php echo e($favorite->id); ?>">
            <button class="btn btn-danger btn-sm" type="submit" data-toggle="tooltip" data-placement="top" title="Eliminar"><i class="fa fa-minus-square" aria-hidden="true"></i></button>
        </form>
            <button class="btn btn-primary btn-sm btn-addcart" value="<?php echo e($favorite->product->id); ?>" data-toggle="tooltip" title="Agregar al carrito" >
                <i class="fa fa-shopping-cart" aria-hidden="true"></i>
            </button>
            <input type="hidden" id="product_id<?php echo e($favorite->product->id); ?>" value="<?php echo e($favorite->product->id); ?>"/>
            <input type="hidden" id="qty" value="1"/>
            <input type="hidden" id="url" value="/cart/add">
        </div>
            
            <table class="table text-center" style="font-size:17px;">
            <thead>
                    <tr>
                        <th class="text-center" style="width:10%;"></th>
                        <th>Producto</th>
                        <th>Description</th>

                    </tr>
            </thead>
            <tbody>
               
                    <tr>
                        <td ><img class="img-responsive" src="<?php echo e($favorite->product->photos()->first()->path); ?>" style="height:75px;"></td>
                        <td> <br>  <a href="<?php echo e(route('show.product', $favorite->product->product_name)); ?>" > <?php echo e($favorite->product->product_name); ?></a></td>
                        <td> <br> <?php echo e($favorite->product->description); ?></td>
                    </tr>
                
            </tbody>
            
            </table>

           </div>

<!-- Fin panel body--></div> 
<?php $i++;?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 <!--Fin collapse-->   </div>
 <div class="text-center" style="position: absolute; bottom: 15px;">
                <?php echo e($favorites->links()); ?>

            </div> 
 <?php else: ?>
<div class="col-md-12 alert alert-warning" style="font-size:15px;">No hay productos favoritos</div>
 <?php endif; ?>
  

<?php $__env->stopSection(); ?>

<?php $__env->startSection('msg'); ?>
<?php if(Session::has('success')): ?>
    <script> 
    $.notify({
        // options
        message: '<strong><?php echo e(Session("success")); ?></strong>' 
    },{
        // settings
        type: 'success',
        delay:5000
    });
    </script>
<?php endif; ?>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('customer.dash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>