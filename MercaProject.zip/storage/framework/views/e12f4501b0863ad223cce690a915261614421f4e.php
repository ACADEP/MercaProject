<div class="modal fade" id="add_product" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title text-center" id="exampleModalLongTitle">Agregar producto</h1>
      </div>
      <div class="modal-body">
        <form action="<?php echo e(route('add-Product')); ?>" method="POST">
            <?php echo e(csrf_field()); ?>

            <div class="form-group col-md-12">
                <input type="text" name="product_name" class="form-control" placeholder="Nombre del producto">
                <br>
                <input type="text" name="product_qty" class="form-control" placeholder="Numero de existencia">
                <br>
                <input type="text" name="product_inv" class="form-control" placeholder="Numero de inventario">
            </div>
            
            <div class="form-row">
                <div class="form-group col-md-6">
                    <input type="numeric" name="product_price" class="form-control" placeholder="Precio del producto">
                </div>
                <div class="form-group col-md-6">
                    <input type="numeric" name="product_reduced" class="form-control" placeholder="Descuento">
                </div>
            </div>
            <?php
                $categorias=App\Category::all();
                $marcas=App\Brand::all();
            ?>
            <div class="form-row">
                <div class="form-group col-md-6">
                    <select name="categoria" class="form-control">
                        <option selected>Categoria</option>
                        <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($categoria->id); ?>"><?php echo e($categoria->category); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group col-md-6">
                    <select name="marca" class="form-control">
                        <option selected>Marca</option>
                        <?php $__currentLoopData = $marcas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $marca): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($marca->id); ?>"><?php echo e($marca->brand_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>

            <div class="form-row">
                <div class="form-group col-md-6">
                    <textarea class="form-control" name="product_des" placeholder="Descripcion" cols="30" rows="10"></textarea>
                </div>
                <div class="form-group col-md-6">
                    <textarea class="form-control" name="product_spec" placeholder="Especificaciones" cols="30" rows="10"></textarea>
                </div>
            </div>
            
            <div class="text-center">
                <button type="submit" class="btn btn-success">Aceptar</button>
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
            </div>
            
        </form>
      </div>
      
    </div>
  </div>
</div>

