
<?php if(session()->has('flash_message')): ?>
    <script>
        swal({
            title: "<?php echo e(session('flash_message.title')); ?>",
            text: "<?php echo e(session('flash_message.message')); ?>",
            type: "<?php echo e(session('flash_message.level')); ?>",
            timer: 2500,
            showConfirmButton: false,
            allowEscapeKey: true,
            allowOutsideClick: true
        },
            function() {
                location.reload(true);
            });
    </script>
<?php endif; ?>

<?php if(session()->has('flash_message_overlay')): ?>
    <script>
        swal({
            title: "<?php echo e(session('flash_message_overlay.title')); ?>",
            text: "<?php echo e(session('flash_message_overlay.message')); ?>",
            type: "<?php echo e(session('flash_message_overlay.level')); ?>",
            confirmButtonText: 'Okay'
        });
    </script>
<?php endif; ?>

<?php if(session()->has('flash_message_custom_error_overlay')): ?>
    <script>
        swal({
            title: "<?php echo e(session('flash_message_custom_error_overlay.title')); ?>",
            text: "<?php echo e(session('flash_message_custom_error_overlay.message')); ?>",
            type: "<?php echo e(session('flash_message_custom_error_overlay.level')); ?>",
            //timer: 5000,
            confirmButtonText: 'Okay',
            allowEscapeKey: true,
            allowOutsideClick: true
        });
    </script>
<?php endif; ?>