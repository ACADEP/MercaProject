<?php $__env->startSection("content"); ?>
<section class="content-header">
        <h1>
           Editar categorías
        </h1> 
</section><br>

<?php if($errors->any()): ?>
<?php $__env->startSection("show-inputs"); ?>

<script>showInputs("<?php echo e(Session('numSubC')); ?>");</script>
<?php Session::forget('numSubC'); Session::forget('subC');?>
<?php $__env->stopSection(); ?>
            <div class="alert alert-danger alert-dismissible" role="alert">
                <ul><button type="button" class="close" data-dismiss="alert" aria-label="Close" ><span aria-hidden="true">&times;</span></button>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li style="list-style-type: none;"><?php echo e($error); ?> </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                </ul>
                
            </div>
<?php endif; ?>

  <form action="<?php echo e(route('edit-category')); ?>" method="POST">
           
           <div class="col-md-6">
           <?php echo e(csrf_field()); ?>

            <input type="hidden" name="category" value="<?php echo e($category->id); ?>">
            <div class="text-right" style="margin-bottom:5px;">
                <button type="submit" class="btn btn-success">Actualizar</button>
                <a type="button" href="<?php echo e(url('admin/products/categories')); ?>" class="btn btn-default" data-dismiss="modal">Regresar</a>
            </div>
            <div class="form-group">
                    <label for="category_name">Nombre de la categoría:</label>
                    <input type="text" name="category_name" maxLength='75' require autocomplete="off"  class="form-control" value="<?php echo e($category->category); ?>" style="width:100%;">
                    </div>
                    <br>
                    <div class="form-group" >
                    <label for="sub_name">Subcategorías:</label>
                    <?php if($category->children()->count()<=0): ?>
                    <br> No exiten subcategorías
                    <?php else: ?>
                    
                        <?php $__currentLoopData = $category->children()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-inline" id="subc-<?php echo e($sub->id); ?>">
                        <button type="button" class="btn btn-danger btn-xs btn-delete-subc" value="<?php echo e($sub->id); ?>" data-toggle="tooltip" value="" data-placement="top" title="Eliminar esta subcategoría"><i class="fa fa-minus-square" aria-hidden="true"></i></button>
                        <input type="text" name="sub_name[]" maxLength='75' require autocomplete="off"  class="form-control" value="<?php echo e($sub->category); ?>" style="width:60%;">
                        </div>
                       
                        <br>
                    
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    
                </div>
           </div>

          
           
                
        
    </form>
    <div class="col-md-6">
          
           <form  id="form-category" action="<?php echo e(route('add-subcategories')); ?>" method="post">
           <?php echo e(csrf_field()); ?>

           <input type="hidden" name="category" value="<?php echo e($category->id); ?>">
           <div class="text-right" style="margin-bottom:5px;">
                <button type="submit" class="btn btn-success">Agregar</button>
            </div>
                <label>Agregar número de subcategorías:</label>
                <select name="subcategorias" id="select-subC" class="form-control" style="width: 50%;">
                    <option value="-1" selected>Ninguna</option>
                    <?php $cont=1; $cSubC=$category->children()->count();?>
                    <?php for($i=$cSubC; $i<5; $i++): ?>
                    <option value="<?php echo e($cont); ?>"><?php echo e($cont); ?></option>
                    <?php $cont++; ?>
                    <?php endfor; ?>
                </select>
                <div id="inputs-subC"></div>  
           
           </form>
           
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("msg-success"); ?>
<?php if(Session::has('success')): ?>
<script> 
    $.notify({
        // options
        message: '<strong><?php echo e(Session("success")); ?></strong>' 
    },{
        // settings
        type: 'success',
        delay:5000
    });
    </script>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("admin.dash", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>