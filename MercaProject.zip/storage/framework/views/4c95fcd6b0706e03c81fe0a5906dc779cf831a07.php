<?php $__env->startSection("content"); ?>

<style>
div.panel-heading {
    margin-bottom: 20px;
}
</style>

<nav aria-label="breadcrumb" style="padding-top: 5px;">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Inicio</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(url('/admin/index')); ?>">Perfil</a></li>
        <li class="breadcrumb-item active" aria-current="page">Ventas</li>
    </ol>
</nav>   

<section class="content-header">
        <h1>
            Ventas
        </h1> 
</section><br>
<?php echo $__env->make('admin.sales.order-sales', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php if($ventas == null): ?>    
    <table class="text-center table">
        <thead>
            <tr>
                <th>Imagen</th>
                <th>Nombre del producto</th>
                <th>Precio unt</th>
                <th>Cliente</th>
                <th>Fecha de la venta</th>
                <th>Cantidad</th>
                <th>Total</th>
            </tr>
        </thead>
        <tbody>
        <?php if($sales->count()>0): ?>
            <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td ><img src="<?php echo e($history->product->photos->first()->path); ?>" height="30px"></td>
                    <td><?php echo e($history->product->product_name); ?></td>
                    <td>$<?php echo e(number_format($history->product->price, 2)); ?></td>
                    <td><?php echo e($history->client); ?></td>
                    <td><?php echo e($history->date); ?></td>
                    <td><?php echo e($history->amount); ?></td>
                    <td>$<?php echo e(number_format($history->total, 2)); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
        <tr>
           <td>No hay ventas</td> 
        </tr>
        <?php endif; ?>
        </tbody>
    
    </table>
    <div class="text-center">
        <?php echo e($sales->appends(Request::input())->links()); ?>

    </div>
<?php else: ?>    
    <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
        <?php 
            $i=1;
            $tot = 0;
        ?>
        <div class="panel panel-default">
            <?php if($ventas->count()>0): ?>
                <?php $__currentLoopData = $ventas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $sold= App\Sale::find($sale->sale_id);?>
                    
                    <div class="panel-heading" role="tab" id="heading<?php echo e($i); ?>">
                        <h4 class="panel-title">
                            <div class="col-sm-10 col-md-10">
                                <a  class="" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse<?php echo e($i); ?>" aria-expanded="true" aria-controls="collapse<?php echo e($i); ?>"> 
                                    <div class="text-left" style="float:left;">Fecha:<span class="label label-default"><?php echo e($sold->date); ?></span></div>
                                    <div style="float:left; margin-left:5px;" class="form-inline"><span class="label label-primary"> Tipo de pago: <?php echo e($sold->pay_method == null ? 'No especificado' :$sold->pay_method); ?></span></div>     
                                </a>
                                <?php if(isset($orderAll)): ?>
                                    <?php if($orderAll==2): ?>
                                    <?php 
                                        $seller_id=App\UserSeller::select('seller_id')->where('client_id', $sold->user_id)->first();
                                        $seller_name=null;
                                        if($seller_id!=null)
                                        {
                                            $seller_name=App\User::select('username')->where('id', $seller_id->seller_id)->first();
                                        }

                                    ?> 
                                    <div style="float:left; margin-left:5px;" class="form-inline"><span class="label label-default"> Vendedor: <?php echo e($seller_name == null ? 'No especificado' :$seller_name->username); ?></span></div>        
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                           
                            <div class="col-sm-2 col-md-2 text-right">
                            <form action="<?php echo e(route('salesPdf',$sold->id)); ?>" style="display:inline;" method="get">
                                <button type="submit" formtarget="_blank" data-placement="top" title="Recibo de pago" class="btn btn-danger btn-xs"><i class="fa fa-file-pdf-o"></i></button>
                            </form>
                                    <button type="button" class="btn btn-primary btn-xs btn-invoice" value="<?php echo e($sold->id); ?>" data-toggle="modal" data-target="#myModal"><i class="fa fa-file-archive-o" aria-hsale_idden="true" title="Subir Factura"></i></button>
                                    <button class="btn btn-danger btn-xs btn-delete-invoice" data-placement="top" title="Quitar Factura" value="<?php echo e($sold->id); ?>"><i class="fa fa-minus-square"></i></button>        
                            </div>
                        </h4>
                    </div>    
                    <div id="collapse<?php echo e($i); ?>" class="<?php echo e($i==1 ? 'panel-collapse collapse in' : 'panel-collapse collapse'); ?>" role="tabpanel" aria-labelledby="heading<?php echo e($i); ?>">
                        <div class="panel-body">        
                            <table class="text-center table">
                                <thead>
                                    <tr>
                                        <th>Imagen</th>
                                        <th>Nombre del producto</th>
                                        <th>Precio unt</th>
                                        <th>Cliente</th>
                                        <th>Fecha de la venta</th>
                                        <th>Cantidad</th>
                                        <th>Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $sale->where('sale_id',$sale->sale_id)->get();; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td ><img src="<?php echo e($history->product->photos->first()->path); ?>" height="30px"></td>
                                            <td><?php echo e($history->product->product_name); ?></td>
                                            <td>$<?php echo e(number_format($history->product->price, 2)); ?></td>
                                            <td><?php echo e($history->client); ?></td>
                                            <td><?php echo e($history->date); ?></td>
                                            <td><?php echo e($history->amount); ?></td>
                                            <td>$<?php echo e(number_format($history->total, 2)); ?></td>
                                        </tr>
                                        <?php $tot = $tot + $history->total ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <div class="text-right"><h4><strong>Total: <span class="label label-success">$<?php echo e(number_format($tot, 2)); ?></span></strong></h4></div>
                        </div>
                    </div>
                    <?php 
                        $i++; 
                        $tot = 0;
                    ?>    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <tr>
                    <td>No hay ventas</td> 
                </tr>
            <?php endif; ?>
        </div>
    </div>

    <div class="text-center">
     
        <?php echo e($ventas->appends(Request::input())->links()); ?>

    </div>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection("msg-success"); ?>
<?php if(Session::has('no-permission')): ?>
<script> 
    $.notify({
        // options
        message: '<strong><?php echo e(Session("no-permission")); ?></strong>' 
    },{
        // settings
        type: 'danger',
        delay:5000
    });
    </script>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('upload-invoice'); ?>   
    <!-- Modal -->
    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title" id="myModalLabel">Subir Factura</h4>
                </div>
                <div class="modal-body">
                    <form action="<?php echo e(route('add-invoice')); ?>" class="dropzone" id="my-awesome-dropzone">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="factura" id="invoice_id">
                    </form> 
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default btn-clear" data-dismiss="modal">Cerrar</button>
                </div>
            </div>
        </div>
    </div>


<script>
    var product_id;
    $(".btn-invoice").click(function(){
        product_id=$(this).val();
        $("#invoice_id").val(product_id);
    });

    // Dropzone.options.myAwesomeDropzone = {
    //     paramName: "file", // Las facturas se van a usar bajo este nombre de parámetro
    //     maxFilesize: 10, // Tamaño máximo en MB
    //     maxFiles: 1, //Número de archivos a subir
    //     acceptedFiles: ".rar,.pdf,.jpg", //Tipos de archivos aceptados
    //     dictDefaultMessage: 'Arrastra las facturas de la venta o seleccionalas (max:1)',
    // };

    var varDrop = new Dropzone('.dropzone',{
        acceptedFiles: '.rar, .zip, .pdf, .jpg',
        maxFileSize: 5,
        maxFiles: 1,
        paramName: 'file',
        dictDefaultMessage: 'Arrastra el archivo zip o rar con la factura de la venta o seleccionala (max:1)',
        dictMaxFilesExceeded: 'Solo se puede subir un archivo a la vez, recarga la paguina para volver a subir',
        dictInvalidFileType: 'Solo se puede subir archivos rar o zip'
    });
    Dropzone.autoDiscover=false;
    
    varDrop.on('error', function(file, res){
        $('.dz-error-message:last > span').text(res.errors.file[0]);
    });
    varDrop.on('success', function(file, res){
        // varDrop.removeFile(file);
    });



</script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make("admin.dash", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>