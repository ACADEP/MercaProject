<?php $__env->startSection('content'); ?>

<nav aria-label="breadcrumb" style="padding-top: 5px;">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Inicio</a></li>
        <li class="breadcrumb-item"><a href="<?php echo e(url('/customer/profile')); ?>">Perfil</a></li>
        <li class="breadcrumb-item active" aria-current="page">Métodos de Pago</li>
    </ol>
</nav>        
    
<section class="content-header">
        <h1>
            Métodos de pago
        </h1>        
</section><br>
<?php if($usercustomer != null): ?>
    <div class="text-center" style="margin-right: 14%; padding-bottom: 20px;">
        <button class="btn btn-success"  data-toggle="modal" data-target="#add_card"><i class="fa fa-plus-square" aria-hidden="true"></i> Agregar</button>
    </div>
<?php else: ?>
    <div class="alert alert-danger fade in">
        <a href="#" class="close" data-dismiss="alert">&times;</a>
        <strong>Error!</strong> Por favor, primero ingrese sus datos personales.
    </div>        
<?php endif; ?>
<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
    <?php if($cardList != null): ?>
        <?php
            $id = 1;
        ?>
        <div class="panel-group col-xs-6 col-sm-6 col-md-6 col-lg-6" id="accordion" style="width: 100%;" role="tablist" aria-multiselectable="true" >
        <?php $__currentLoopData = $cardList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cards): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="panel panel-default" id="card<?php echo e($cards->id); ?>">
                    <div class="panel-heading" role="tab" id="heading<?php echo e($id); ?>">
                        <h4 class="panel-title" style="float: left;">
                            <a class="collapsed lead" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse<?php echo e($id); ?>" aria-expanded="true" aria-controls="collapse<?php echo e($id); ?>">
                                Tarjeta termina en <?php echo e($cards->card_number); ?>

                            </a>
                        </h4>
                        <div class="form-inline" style="margin-left: 95%;">
                            <button class="btn btn-danger btn-xs btn-delete" data-toggle="tooltip" value="<?php echo e($cards->id); ?>" data-placement="top" title="Eliminar"><i class="fa fa-minus-square" aria-hidden="true"></i></button>
                        </div> 
                    </div>
                    <div id="collapse<?php echo e($id); ?>" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading<?php echo e($id); ?>">
                        <div class="panel-body">
                            <label class="lead" for="">Tarjeta: <?php echo e($cards->card_number); ?></label><br>
                            <label class="lead" for="">Titular: <?php echo e($cards->holder_name); ?></label><br>
                            <label class="lead" for="">Vigencia: <?php echo e($cards->expiration_month.'/'.$cards->expiration_year); ?></label><br>
                            <label class="lead" for="">Marca: <?php echo e($cards->brand); ?></label>
                        </div>
                    </div>
                </div>
                <?php
                    $id++;
                ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('mostrar-modal'); ?>
    <?php if($errors->any()): ?>
        <script>
            $(function() {
                $('#add_card').modal('show');
            });
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('customer.dash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>