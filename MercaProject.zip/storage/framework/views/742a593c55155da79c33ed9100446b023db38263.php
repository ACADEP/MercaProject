<?php $__env->startSection('content'); ?>

<section class="content-header">
        <h1>
            Métodos de pago
        </h1>        
</section><br>
<div class="text-center" style="margin-right: 14%; padding-bottom: 20px;">
    <button class="btn btn-success"  data-toggle="modal" data-target="#add_card"><i class="fa fa-plus-square" aria-hidden="true"></i> Agregar</button>
</div>
<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
    <?php if($usercards != null): ?>
        <?php
            $id = 1;
        ?>
        <div class="panel-group col-xs-6 col-sm-6 col-md-6 col-lg-6" id="accordion" style="width: 100%;" role="tablist" aria-multiselectable="true" >
        <?php $__currentLoopData = $usercards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cards): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="panel panel-default" id="card<?php echo e($cards->id); ?>">
                    <div class="panel-heading" role="tab" id="heading<?php echo e($id); ?>">
                        <h4 class="panel-title" style="float: left;">
                            <a class="collapsed lead" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapse<?php echo e($id); ?>" aria-expanded="false" aria-controls="collapse<?php echo e($id); ?>">
                                <?php
                                    $acorcard = substr($cards->numtarjeta, 12, 16);
                                ?>
                                Tarjeta termina en <?php echo e($acorcard); ?>

                            </a>
                        </h4>
                        <div class="form-inline" style="margin-left: 95%;">
                            <button class="btn btn-danger btn-xs btn-delete" data-toggle="tooltip" value="<?php echo e($cards->id); ?>" data-placement="top" title="Eliminar"><i class="fa fa-minus-square" aria-hidden="true"></i></button>
                        </div> 
                    </div>
                    <div id="collapse<?php echo e($id); ?>" class="panel-collapse collapse" role="tabpanel" aria-labelledby="heading<?php echo e($id); ?>">
                        <div class="panel-body">
                            <label class="lead" for="">Tarjeta: <?php echo e($cards->numtarjeta); ?></label><br>
                            <label class="lead" for="">Titular: <?php echo e($cards->titular); ?></label><br>
                            <label class="lead" for="">Vigencia: <?php echo e($cards->vigencia); ?></label><br>
                            <label class="lead" for="">CVC: <?php echo e($cards->cvc); ?></label>
                        </div>
                        <!-- <div class="form-inline" style="margin-left: 95%;">
                            <button class="btn btn-danger btn-xs btn-delete" data-toggle="tooltip" value="<?php echo e($cards->id); ?>" data-placement="top" title="Eliminar"><i class="fa fa-minus-square" aria-hidden="true"></i></button>
                        </div>  -->
                    </div>
                </div>
                <?php
                    $id++;
                ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('mostrar-modal'); ?>
    <?php if($errors->any()): ?>
        <script>
            $(function() {
                $('#add_card').modal('show');
            });
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('customer.dash', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>