<li class="nav-item dropdown" >
                            
    <a class="nav-link hidden-md-down"  role="button" href="#" id="navbarDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <i class="material-icons"> shopping_cart</i><span class="badge" id="badge-cart"><?php echo e(Auth::check() ? Auth::user()->cart->count() : '0'); ?></span>
    </a>
    
    <ul class="dropdown-menu" style="width:220px;" aria-labelledby="navbarDropdown">
    
        <li style="width:100%;">
       
            <div <?php echo e(Auth::check() ? 'id=client-container' : 'id=product_container'); ?> class="row">
            <?php if(Auth::check()): ?>
            
                <script>borrarCache();</script>
                <?php $tItems=0 ?>
                   
                <?php $__currentLoopData = Auth::user()->cart->with('product')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <?php if($tItems<=4): ?>
                   
                        <div class="col-md-3"> <img  style="width:100%;" src="<?php echo e($cartItem->product->photos()->first()->path); ?>"></div>
                        <div class="col-md-9" ><span class="badge badge-primary" style="font-size:12px; width:100%;"><?php echo e($cartItem->product->product_name); ?></span> <br><span class="badge badge-success">$<?php echo e(number_format($cartItem->product->price-$cartItem->product->reduced_price, 2)); ?></span> </div>
                        <div class="col-md-12 "><hr></div>
          
                    <?php endif; ?>
                    <?php $tItems++ ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
            <?php endif; ?>
            </div>
            
        </li>
          
        <li class="text-center" style="width:100%;" >
            <a  href="<?php echo e(route('cart')); ?>"  id="cart-detail">Ver carrito</a>   
        </li>
           
    </ul>
</li>
   

