<li class="nav-item dropdown" >
                            
    <a class="nav-link hidden-md-down"  role="button" href="#" id="navbarDropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        <i class="material-icons"> shopping_cart</i><span class="badge"><?php echo e(Auth::check() ? Auth::user()->cart->count() : '0'); ?></span>
    </a>
    
    <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
        <li>
            <div <?php echo e(Auth::check() ? 'id=client-container' : 'id=product_container'); ?> >
            <?php if(Auth::check()): ?>
                <script>borrarCache();</script>
                <?php $tItems=0 ?>
                <?php $__currentLoopData = Auth::user()->cart->with('product')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($tItems<=4): ?>
                            <?php echo e($cartItem->product->product_name); ?>

                            <br>---------------------<br>
                    <?php endif; ?>
                    <?php $tItems++ ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            </div>
        </li>
                                           
        <li class="total">
            <span <?php echo e(Auth::check() ? 'id=total-items-client' : 'id=total-items'); ?>><strong>Total</strong>: $<?php echo e(Auth::check() ? number_format(Auth::user()->total, 2) : '0'); ?></span>
            
            <?php if(Auth::check()): ?>
                <a href="<?php echo e(route('cart.payment')); ?>" class="btn btn-success btn-xs btn-pay">Pagar</a>
            <?php endif; ?>
        </li>
        <li class="text-center">
            <a href="<?php echo e(route('cart')); ?>" id="cart-detail">Ir a detalles</a>      
        </li>
           
    </ul>
</li>
   

