<?php
 return array (
  'paginate_general' => '10',
  'api' => 
  array (
    'api_key_openpay' => 'sk_1c3df6f065b64e7995b099068e908d05',
    'openpay_client_id' => 'mqddgjnqvgl6mhtp8xmo',
    'api_key_enviaya' => '91fd302dde92bf5160e6b261b680b1c1',
    'paypal-type' => 'sandbox',
    'pay-pal-key' => 'AcbJmhLyQjcEbqe44-pfFrSk3UrV03SwoFSgFgwwoFfiCl8Qjda6ePlsHIyb0nCjzhOQDkUgsya5EHXn',
  ),
  'company' => 
  array (
    'name' => 'Acadep',
    'country_code' => 'MX',
    'postal_code' => '23000',
    'direction_1' => 'Allende',
    'city' => 'La Paz',
    'phone' => '6121225174',
  ),
  'general' => 
  array (
    'main_logo' => '/images/2LCgOXDQ8ORQVRwC806T9RxEAiTnyxVxEtqmjA8f.png',
    'mini_logo' => '/images/Md.png',
    'carrusel_slogan' => 'Bienvenidos a nuestra tienda en línea te damos los mejores precios en tecnología comprando donde quieras!!',
    'carrusel_1' => '/images/slider/main_2.jpg',
    'carrusel_2' => '/images/slider/iPhone_1.jpg',
    'carrusel_3' => '/images/aYwPmHOgQp7a2yj6Mscmn0BjuceScXUe7jHPumLe.jpeg',
    'store_name' => 'Mercadata',
    'pct' => '25',
  ),
  'mk' => 
  array (
    'slogan' => 'Tu tienda de tecnologia en línea',
    'information_final' => 'En espera de vernos favorecidos con su pedido, nos ponemos a sus ordenes para cualquier aclaración.',
    'information_final_2' => '* Precios sujetos a cambio sin previo aviso.',
    'information_final_3' => 'A partir de 24 horas tiene 7 días para solicitar su factura al correo de Mercadata.',
    'greetings' => '¡Gracias por hacer su compra!',
  ),
) ;