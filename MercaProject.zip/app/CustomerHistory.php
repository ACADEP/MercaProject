<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CustomerHistory extends Model
{
    //
}
