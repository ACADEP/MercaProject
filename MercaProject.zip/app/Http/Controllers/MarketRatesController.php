<?php

namespace App\Http\Controllers;
use App\Product;
use App\MarketRates;
use App\MarketRatesDetail;
use App\Sale;
use App\CustomerHistory;
use App\OrderOxxo;
use App\Http\Requests\MarketRateRequest;

use Illuminate\Http\Request;
use Carbon\Carbon;
use Barryvdh\DomPDF\Facade as PDF;
use App\Mailers\AppMailers;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;

class MarketRatesController extends Controller
{
    public function market_rates()
    {
        $market_rates=MarketRates::all();
        return view("admin.market_rates.index", compact('market_rates'));
    }

    public function showCreate()
    {
        $marketrate=new MarketRates;
        return view("admin.market_rates.create", compact('marketrate'));
    }

    public function showEdit(MarketRates $marketrate)
    {
        return view("admin.market_rates.edit", compact('marketrate'));
    }
    
    public function searchMarket_rates(Request $request)
    {
        $search=null;
        $search_find=$request->search;

        if( $search_find!=null)
        {
            // Returns an array of products that have the query string located somewhere within
            // our products product name. Paginate them so we can break up lots of search results.
            $query=Product::select("products.*")->join('brands', 'brand_id', '=', 'brands.id')
                                        ->join('categories', 'cat_id', '=', 'categories.id');  
                                                 
            $query = $query->orWhere("brand_name", 'LIKE', "%$search_find%");
            $query = $query->orWhere("category", 'LIKE', "%$search_find%");
            $query = $query->orWhere("product_name", 'LIKE', "%$search_find%");
            $query = $query->orWhere("description", 'LIKE', "%$search_find%");
            $query = $query->orWhere("product_sku", 'LIKE', "%$search_find%");
            $search = $query->orderBy("products.product_name")->paginate(10);
           
            
        }
        session()->flashInput($request->input());
        $marketrate=new MarketRates;
        return view("admin.market_rates.create", compact('search','marketrate'));
        
    }
    public function searchMarket_ratesedit(Request $request)
    {
        $search=null;
        $search_find=$request->search;
        if( $search_find!=null)
        {
            // Returns an array of products that have the query string located somewhere within
            // our products product name. Paginate them so we can break up lots of search results.
            $query=Product::select("products.*")->join('brands', 'brand_id', '=', 'brands.id')
                                        ->join('categories', 'cat_id', '=', 'categories.id');  
                                                 
            $query = $query->orWhere("brand_name", 'LIKE', "%$search_find%");
            $query = $query->orWhere("category", 'LIKE', "%$search_find%");
            $query = $query->orWhere("product_name", 'LIKE', "%$search_find%");
            $query = $query->orWhere("product_sku", 'LIKE', "%$search_find%");
            $query = $query->orWhere("description", 'LIKE', "%$search_find%");
            $search = $query->orderBy("products.product_name")->paginate(10);
           
            
        }

        
        session()->flashInput($request->input());
        $marketrate=MarketRates::find($request->market);
        return view("admin.market_rates.edit", compact('search', 'marketrate'));
        
       
    }
    public function createMarket_rates(MarketRateRequest $request)
    {
        
        $request["date"]=Carbon::now();

        $market_rate=MarketRates::find($request->marketRate);
        if($market_rate->MarketRatesDetails()->count()>0)
        {
            $market_rate->update($request->all());
            return redirect("/admin/market_rates")->with("success", "Cotizacion creada");
        }
        else
        {
            return redirect("/admin/market_rates/create")->with("fail", "Agregar productos para crear la cotización")->withInput();
        }
        
    }

    public function updateMarket_rates(MarketRateRequest $request)
    {
        $market_rate=MarketRates::find($request->marketRate);
        $market_rate->update($request->all());
        $market_rate->save();

        return redirect("/admin/market_rates")->with("success", "Cotizacion actualizada");
    }
    public function deleteProductMarket_ratesEdit(Request $request)
    {
        
        $market_rate_detail=MarketRatesDetail::find($request->detail_id);

        $market_rate=MarketRates::find($market_rate_detail->market_rates_id);
        $market_rate->total= $market_rate->total-$market_rate_detail->subtotal;
        $market_rate->save();

        $market_rate_detail->delete();
        return response("Producto eliminado de cotización",200);
    }

    public function addMarket_rates(Request $request)
    {
       
        $market_rate_detail=null;
        $market_rate=null;
        if($request->market_id==null || $request->market_id=='undefined')   //Nueva cotización
        {
            $market_rate=new MarketRates;
           
        }
        else
        {
            $market_rate=MarketRates::find($request->market_id);
        }
       
        
        $market_rate->total=($request->product_price*$request->product_qty)+$market_rate->total;
        
        
        $market_rate->save();
        
        $market_rate_detail=new MarketRatesDetail;
        $market_rate_detail->market_rates_id=$market_rate->id;
       
        $market_rate_detail->thumbnail=$request->product_photo;
        $market_rate_detail->unity="PRODUCTO";
        $market_rate_detail->qty=$request->product_qty;
        $market_rate_detail->product_sku=$request->product_sku;
        $market_rate_detail->description=$request->product_name;
        $market_rate_detail->price=$request->product_price;
        $market_rate_detail->subtotal=($request->product_price)*$request->product_qty;
        
        
        $market_rate_detail->save();
        
        return response(["detail"=>$market_rate_detail, "market_id"=>$market_rate->id],200);
    }

    public function addNewMarket_rates(Request $request)
    {
        $market_rate_detail=null;
        $market_rate=null;
        if($request->market_id==null || $request->market_id=='undefined')   //Nueva cotización
        {
            $market_rate=new MarketRates;
           
        }
        else
        {
            $market_rate=MarketRates::find($request->market_id);
        }
       
        if($request->tab_active=="service")
        {
            $market_rate->total=($request->service_price*$request->qty_service)+$market_rate->total;
        }
        else
        {
            $market_rate->total=($request->product_price*$request->qty_product)+$market_rate->total;
        }
        
        $market_rate->save();
        
        $market_rate_detail=new MarketRatesDetail;
        $market_rate_detail->market_rates_id=$market_rate->id;
        if($request->tab_active=="service")
        {
            $request->validate([
                "unity"=>"required",
                "qty_service"=>"required",
                "summary"=>"required",
                "service_price"=>"required"
            ],
            [
                "unity.required"=>"Ingresar la unidad del servicio",
                "qty_service.required"=>"Ingresar la cantidad del servicio",
                "summary.required"=>"Igresar una descripción ",
                "service_price.required"=>"Ingresar un costo al servicio"
            ]);
            $market_rate_detail->thumbnail="/images/service.png";
            $market_rate_detail->unity=$request->unity;
            $market_rate_detail->qty=$request->qty_service;
            $market_rate_detail->product_sku="Servicio";
            $market_rate_detail->description=$request->summary;
            $market_rate_detail->price=$request->service_price;
            $market_rate_detail->subtotal=($request->service_price)*$request->qty_service;
        }
        else
        {
            $request->validate([
                
                "qty_service"=>"required",
                "product_name"=>"required",
                "product_price"=>"required"
            ],
            [
               
                "qty_service.required"=>"Ingresar la cantidad del servicio",
                "product_name.required"=>"Igresar un nombre del producto",
                "product_price.required"=>"Ingresar un costo al servicio"
            ]);
            $market_rate_detail->thumbnail="/images/no-image-found.jpg";
            $market_rate_detail->unity="PRODUCTO";
            $market_rate_detail->qty=$request->qty_product;
            $market_rate_detail->product_sku=$request->product_sku ? $request->product_sku : "No ingresado";
            $market_rate_detail->description=$request->product_name;
            $market_rate_detail->price=$request->product_price;
            $market_rate_detail->subtotal=($request->product_price)*$request->qty_product;
        }
        
        $market_rate_detail->save();
        
        
        
        return response(["detail"=>$market_rate_detail, "market_id"=>$market_rate->id],200);
    }
    public function addMarket_ratesEdit(Request $request)
    {
        
       
            $product=Product::find($request->product_id);
            $market_rate=MarketRates::find($request->market_id);
            
           
            if(!$market_rate->productRepeat($product->id))
            {
              
                $market_rate->total=($product->mr_price*$request->qty)+$market_rate->total;
                $market_rate->save();

                $market_rate_detail=new MarketRatesDetail;
                $market_rate_detail->market_rates_id=$request->market_id;
               
                $market_rate_detail->thumbnail="/images/no-image-found.jpg";
                $market_rate_detail->qty=$request->qty;
                $market_rate_detail->product_sku=$product->product_sku;
                $market_rate_detail->description=$product->description;
                $market_rate_detail->price=$product->mr_price;
                $market_rate_detail->subtotal=($product->mr_price)*$request->qty;
                $market_rate_detail->save();
                
                return back();
            }
            else
            {
                return back()->with("alert", "Este Producto ya se encuentra en la cotización");
            }

            
    }

    public function deleteProductMarket_rates(Request $request)
    {
       
        $market_rate_detail=MarketRatesDetail::find($request->detail_id);

        $market_rate=MarketRates::find($market_rate_detail->market_rates_id);
        $market_rate->total= $market_rate->total-$market_rate_detail->subtotal;
        $market_rate->save();

        $market_rate_detail->delete();
        return response("Producto eliminado de cotización",200);
    }

    public function deleteMarket_rates(Request $request)
    {
        
        if($request->market_id!=null)
        {
            $market_rate=MarketRates::find($request->market_id);

            if($market_rate)
            {
                $market_rate->MarketRatesDetails()->delete();
                $market_rate->delete();
            }
            
        }
        
        
        return response("Cotizacion eliminada",200);
    }

    public function PDF(MarketRates $marketrate)
    {
        $items=$marketrate;
        // $pdf = PDF::loadView('admin.market_rates.pdf-print',compact('items'));
        $pdf = PDF::loadView('admin.market_rates.pdf-template',compact('items'));
        return $pdf->stream('Cotización'.$items->date.'.pdf');
      
    }

    public function sendMarketRate(AppMailers $mailer, MarketRates $marketrate)
    {
        if($marketrate->email!="" || $marketrate->email!=null)
        {
            $mailer->sendMarketRateReceipt($marketrate);
            if($mailer)
            {
                return back()->with("email-sended","Correo enviado con éxito");
            }
            else
            {
                return back()->with("fail","Correo no enviado favor de verificar el correo o intentar de nuevo");
            }
        }
        else
        {
            return back()->with("fail","Ingresar un correo valido");
        }
        
        
    }

    public function searchMarketRates(Request $request)
    {
        $search=null;
        $search_find=$request->search;
        if( $search_find!=null || $search_find!="")
        {
           
            $query=MarketRates::select("*");
                                                 
            $query = $query->orWhere("id", 'LIKE', "%$search_find%");
            $query = $query->orWhere("company", 'LIKE', "%$search_find%");
            $query = $query->orWhere("email", 'LIKE', "%$search_find%");
            $market_rates = $query->get();
           
            
        }
        else
        {
            $market_rates=MarketRates::all();
        }
       
        return view("admin.market_rates.index", compact('market_rates'));
    }

    public function sendEmailMarketRate(AppMailers $mailer, Request $request)
    {
        
        $market_rate=MarketRates::find($request->markerate);
        $market_rate->company=$request->company;
        $market_rate->email=$request->email;
        if($market_rate->date==null)
        {
            $market_rate->date=Carbon::now();
        }
        $market_rate->save();

        $mailer->sendMarketRateReceipt($market_rate);
        if($mailer)
        {
            return back()->with("email-sended","Correo enviado con éxito");
        }
        else
        {
            return back()->with("fail","Correo no enviado favor de verificar el correo o intentar de nuevo");
        }
    }

    public function addOrder(Request $request)
    {
       
        $market_rate=MarketRates::find($request->marketrate);
        $sale= new Sale;
        $sale->Insert($market_rate->total,"","","Pago por acreditar",null,"Pago por acreditar","Cotización");
        $items=$market_rate;
        $pdf = PDF::loadView('admin.market_rates.pdf-pay',compact('items'));
        Session::put('pay-marketrate',  $pdf->stream('Recibo-pago.pdf'));
        Session::save(); 
        foreach($market_rate->MarketRatesDetails()->get() as $detail)
        {
            $history= new CustomerHistory;
            $history->sale_id=$sale->id;
            $history->product_id=$detail->product_id;
            $history->product_name=$detail->product->product_name;
            $history->product_price=$detail->price;
            $history->amount=$detail->qty;
            $history->save();
        }
        $orOxxo=new OrderOxxo;
        $orOxxo->insert(Auth::user()->id,$sale->id, $market_rate->id);

        return back();
    }
    public function showPDFPay()
    {
        if(Session::has('pay-marketrate'))
        {
            $pdf=session("pay-marketrate");
            Session::forget('pay-marketrate');
            return $pdf;
        }
        else
        {
            return back();
        }
    }
}
