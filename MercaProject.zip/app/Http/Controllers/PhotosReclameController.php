<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PhotosReclameController extends Controller
{
    //
}
