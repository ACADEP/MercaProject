<?php

namespace App;

use App\Customer;
use Illuminate\Notifications\Notifiable;
use Illuminate\Contracts\Auth\CanResetPassword;
use Illuminate\Auth\Passwords\CanResetPassword as ResetPassword;
use Illuminate\Foundation\Auth\User as Authenticatable;
// use Laravel\Cashier\Billable;


class User extends Authenticatable
{
    use Notifiable;
    // use Billable;
    
    protected $table = 'users';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'username', 'email', 'password', 'admin',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    /**
     * Make a boot function to listen
     * to any model events that are fired below.
     */
    public static function boot() {
        // Reference the parent class
        parent::boot();

        // When we are creating a record (for user registration),
        // then we want to set a token to some random string.
        static::creating(function($user) {
            $user->token = str_random(30);
        });
       
    }


    /**
     * Confirm the users email by
     * setting verified to true,
     * token to a NULL value,
     * then save the results.
     */
    public function confirmEmail() {
        $this->verified = true;
        $this->token = null;
        $this->save();
    }

    public function carts()
    {
        return $this->hasMany(Cart::class);
        
    }

    public function productseller()
    {
        return $this->hasMany(ProductSeller::class);
    }

    public function selehistories()
    {
        return $this->hasMany(SeleHistory::class);
    }
    public function sale()
    {
        return $this->hasMany(Sale::class);
    }

    public function favorites()
    {
        return $this->hasMany(Favorite::class);
    }
    public function customer()
    {
        return $this->hasOne(Customer::class,"usuario");
    }
    public function ordersOxxo()
    {
        return $this->hasMany(OrderOxxo::class);
    }
    
    public function payments()
    {
        return $this->hasMany(PaymentInformation::class,'usuario');
    }

    public function product($id)
    {   
        $product=Product::find($id);
        return $product;
    }

    public function address()
    {
        return $this->hasMany(Address::class, 'usuario');
    }

    public function addressActive()
    {
        $addresses=$this->address()->get();
        $address_active="";
        foreach($addresses as $address)
        {
            if($address->activo==1)
            {
                $address_active=$address;
            }
        }
        return $address_active;
    }

    public function updateAddressActive($id)
    {
        $addresses=$this->address()->get();
        foreach($addresses as $address)
        {
            $address->activo=0;
            $address->update();
        }
        $addressActive=$this->address()->where("id",$id)->first();
        if($addressActive!=null)
        {
            $addressActive->activo=1;
            $addressActive->update();
        }
        

        return $addressActive;
    }
    public function valFavorite($product_id)
    {
        $band=true;
        $favorites=$this->favorites()->get();
        foreach($favorites as $favorite)
        {
            if($favorite->product->id == $product_id)
            {
                $band=false;
            }
        }
        return $band;
    }
    public function paymentscard()
    {
        return $this->hasMany(PaymentInformation::class, 'usuario');
    }
    
    public function shipments()
    {
        return $this->hasMany(Shipment::class,'id_seller');
    }

    public function getTotalAttribute()
    {
        $cartUser= $this->carts()->where('status', 'Active')->get();
        $total=0;
        foreach($cartUser as $cartItem)
        {
            $total+=$cartItem->total;
        }
        return $total;
    }
    public function productIs($id)
    {   
        $band=false;
        $cart = $this->cart->get();
        foreach($cart as $cartItem)
        {
            if($cartItem->product_id==$id)
            {
                $band=true;
            }
        }
        return $band;

    }
    
    public function getCartAttribute()
    {
        $cart = $this->carts()->where('status', 'Active');
        if ($cart)
            return $cart;

        // else
        $cart = new Cart();
        $cart->status = 'Active';
        $cart->user_id = $this->id;
        $cart->save();

        return $cart;
    }

}
