# Checkout with PayPal demo using REST API with Checkout.js V4
Servlet Web Application showcasing PayPal Express Checkout using raw PayPal REST APIs with Checkout.js V4 

### Quick Set up and run

1) Locate the checkout.war file in the dist folder. 
2) Copy the war file and deploy in your Tomcat webapps folder.
3) Opening localhost:8080/checkout in your browser will fire the html page.


### Eclipse Setup

Copy the code sample on your local machine

Open Eclipse -> File -> Import -> General -> Existing projects to into workspace

Browse the location of the project - Finish the import

Add Apache Tomcat to Project Facets Runtime 

###### Jars Needed

> commons-codec-1.7.jar (Libs for handling encoder, decoder)

> json-20140107.jar (Helper for handling JSON)

> okhttp-3.9.0.jar (Http request)

> okio-1.13.0.jar (Http request)

The above jars are available in lib folder under WebContent -> WEB-INF -> lib

##### Build path

1) Add the above jars to your java built path (Right click the project in eclipse choose properties -> Java Build Path -> Add Jars -> Select the current project, browse to lib folder select all the jars and complete the process)

2) Add the appropriate Java Runtime Environment to your build path
3) Add Apache Tomcat to your build path

###### Run

1. Configure Apache Tomcat on your eclipse

2. Right click the project Run As -> Run on Server.

3. Open the below URL in browser

>http://localhost:8080/{your_project_name}/


###### Flow

1) Clicking on the yellow PayPal Checkout button will showcase the Express Checkout flow

2) Clicking on the blue Proceed to Checkout button will showcase the typical Guest Checkout flow


###### App Configuration 

Application configuration is configured in 'application.properties' file found in WEB-INF - > application.properties file

Change the config according to your app (Client Id, Secret).

Setting 'IS_APPLICATION_IN_SANDBOX' field in application.properties file to 'true' will run the app in sandbox environment and 'false' will run in Live environment.

###### Package Explanation

>com.paypal.demo.dto - Holds DTO classes to generate the payload needed for create payments api call.

>com.paypal.demo.helpers - Holds Helper class to map values from html to DTO and to generate random invoice no, methods to invoke API calls (post, get, getAccessToken, API invocation methods)

>com.paypal.demo.servlets - Servlets to make api calls to PayPal server

Html files are placed in WebContent folder


Note: The current code uses Java 8. So, it uses TLS_v1.2 protocol by default. Upgrade to Java 8 may be necessary.

